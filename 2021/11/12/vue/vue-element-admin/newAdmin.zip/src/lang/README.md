# 国际化文件
- zh.js
 · 中文文件
- en.js
 · 英文文件
 
 # 使用方式
```html
<p>{{ $t('navbar.title') }}</p>
```
```js
this.$t('navbar.title')
```