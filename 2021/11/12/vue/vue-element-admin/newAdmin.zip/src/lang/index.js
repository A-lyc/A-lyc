import Vue from 'vue'
import VueI18n from 'vue-i18n'
import enLocale from './en'
import zhLocale from './zh'
import { getLang } from '@/utils/auth'

Vue.use(VueI18n)

const messages = {
  en: {
    ...enLocale,
  },
  zh: {
    ...zhLocale,
  }
}
/**
 * 需要在浏览器保存一个表示标识这个时什么语言的，之后使用getToken('lang')类似，需要修改一下，这个时获取token的
 * 所以需要修改获取语言的一个，需要重写获取语言，在autg.js中再次重写一下
 * 之后在调取这个方法去获取语言的判断，下面的时默认获取，因为第一次是没有的，所以||后面你的一个默认语言zh
 * */
let lang = getLang()
const i18n = new VueI18n({
  locale: lang || 'zh', // set locale
  messages // set locale messages
})

export default i18n
