export default {
  navbar: {
    title: '我是中文'
  }
}
