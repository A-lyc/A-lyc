export default {
  navbar: {
    title: 'I am English'
  }
}
