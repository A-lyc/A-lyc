import Cookies from 'js-cookie'

const TokenKey = 'token'
const Lang = 'lang'
// 获取token
export function getToken() {
  return Cookies.get(TokenKey)
}

// 写入token
export function setToken(token) {
  return Cookies.set(TokenKey, token)
}

// 删除token
export function removeToken() {
  return Cookies.remove(TokenKey)
}

// 获取Lang
export function getLang() {
  return Cookies.get(Lang)
}
// 写入Lang
export function setLang(item) {
  return Cookies.set(Lang, item)
}
// 删除Lang
export function removeLang() {
  return Cookies.remove(Lang)
}


