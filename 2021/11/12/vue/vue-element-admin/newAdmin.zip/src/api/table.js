import request from '@/utils/request'
// 获取数据
export function getList(params) {
  return request({
    url: '/table/list',
    method: 'get',
    params
  })
}

// table 删除
export function setDelete(data) {
  return request({
    url: '/table/del',
    method: 'delete',
    data
  })
}

