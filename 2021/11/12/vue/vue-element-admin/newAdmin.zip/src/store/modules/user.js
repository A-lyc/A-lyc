import { login, logout, getInfo } from '@/api/user'
import { getToken, setToken, removeToken, setLang,removeLang } from '@/utils/auth'
import { resetRouter } from '@/router'

const getDefaultState = () => {
  return {
    token: getToken(),
    name: '',
    avatar: ''
  }
}

const state = getDefaultState()

const mutations = {
  RESET_STATE: (state) => {
    Object.assign(state, getDefaultState())
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  }
}

const actions = {
  // user login - ok
  login({ commit }, userInfo) {
    const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      console.log('---- 登录 ----')
      // 网络请求 .trim()去除空格
      login({ username: username.trim(), password: password }).then(response => {
        const { data } = response
        console.log('---- 登录成功 ----')
        commit('SET_TOKEN', data.token)
        setToken(data.token)
        setLang('en')
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // get user info
  getInfo({ commit, state }) {
    console.log('我是不是刷新就执行的一个人')
    return new Promise((resolve, reject) => {
      // 网络请求获取数据
      getInfo(state.token).then(response => {
        console.log('---- 获取用户信息 ----')
        const { data } = response
        if (!data) {
          return reject('验证失败，请重新登录。')
        }
        const { name, avatar } = data
        // 更改数据
        commit('SET_NAME', name)
        commit('SET_AVATAR', avatar)
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        removeToken() // must remove  token  first
        resetRouter()
        removeLang()
        commit('RESET_STATE')
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      removeToken() // must remove  token  first
      commit('RESET_STATE')
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

