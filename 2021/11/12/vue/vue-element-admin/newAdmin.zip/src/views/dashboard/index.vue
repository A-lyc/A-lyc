<template>
  <div class="dashboard-container">
    <div class="dashboard-text">name: {{ name }}</div>
    <p>{{ $t('navbar.title') }}</p>
    <div class="content" ref="content" style="display: flex;text-align: center">
      <div ref="left" style="width: 120px">
        <div v-for="item in 3" style="border: 1px solid red;margin-bottom: 20px">{{item}}
          <div style="width: 120px" ref="nei">
            <div v-for="item in 3" style="border: 1px solid red;margin-bottom: 20px">{{item}} + 2
          </div>
        </div>
        </div>
      </div>
      <div style="width: 120px"></div>
      <div ref="right" style="width: 120px;text-align: center">
        <div v-for="item in 10" style="border: 1px solid red;margin-bottom: 20px">* + {{item}} + *</div>
      </div>
    </div>
    <div class="dashboard-text"  @click="handleLanguage('en')">
      <canvas ref="canvas"></canvas>
    </div>
    <div class="dashboard-text" ref="echarts"  style="width: 600px;height:400px;"></div>
    <toast :isShow="true"></toast>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Toast from '@/plugin/toast'
const QRCode = require('qrcode')
const echarts = require('echarts')
const flatpickr = require("flatpickr")
const dragula = require("dragula")

export default {
  name: 'Dashboard',
  components: { Toast },
  computed: {
    ...mapGetters([
      'name'
    ])
  },
  mounted() {
    console.log("this.$t('navbar.title')")
    console.log(this.$t('navbar.title'))
    console.log('this.$refs[canvas]')
    console.log(this.$refs['canvas'])
    console.log('this.$toast')
    console.log(this.$toast)
    console.log('this.$toast')
    console.log('dragula')
    dragula([this.$refs['left'], this.$refs['right']]).on('over', function(el) {
      console.log('---- 被移动的元素 ----')
      console.log(el)
    })
    setTimeout(()=> {
      console.log(this.$refs['content'])
    },10000)
    this.$toast.isShow('我们都是好朋友', 10000)
    // If using flatpickr in a framework, its recommended to pass the element directly
    flatpickr('#myID', {
      enableTime: true,
      dateFormat: "Y-m-d H:i",
    })
    // 生成二维码 -  获取页面元素 需要在页面挂在之后完成的
    let canvas = this.$refs['canvas']
    QRCode.toCanvas(canvas, 'sample text', { errorCorrectionLevel: 'H' }, function (error,url) {
      if (error) console.error(error)
      console.log('success!')
      console.log(url)
    })
    // 图表 - 需要页面挂在之后完成
    let echart = this.$refs['echarts']
    console.log(echarts)
    var myChart = echarts.init(echart)
    var option = {
      legend: {},
      tooltip: {},
      dataset: {
        // 提供一份数据。
        source: [
          ['product', '2015', '2016', '2017', '2018'],
          ['Matcha', 43.3, 85.8, 93.7],
          ['Milk', 83.1, 73.4, 55.1],
          ['Cheese', 86.4, 65.2, 82.5],
          ['W', 72.4, 53.9, 39.1],
          ['Wal=', 70, 1, 90,100],
          ['Waln', 70, 1, 90,100],
          ['Walnu', 70, 1, 90,100],
          ['Walnut', 70, 1, 90,100],
        ]
      },
      // 声明一个 X 轴，类目轴（category）。默认情况下，
      // 类目轴对应到 dataset 第一列。
      xAxis: {type: 'category'},
      // 声明一个 Y 轴，数值轴。
      yAxis: {},
      // 声明多个 bar 系列，默认情况下，每个系列会自动对应到 dataset 的每一列。
      series: [
        {type: 'bar'},
        {type: 'bar'},
        {type: 'bar'},
        {type: 'bar'},
      ]
    }
    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option)
  },
  methods: {
    handleLanguage(item) {
      console.log()

      // this.$cookies.set("language", item)
      location.reload()
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
