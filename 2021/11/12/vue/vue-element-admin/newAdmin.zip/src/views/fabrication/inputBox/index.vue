<template>
    <div>
      <input type="text" />
    </div>
</template>

<script>
  export default {
    name: 'inputBox'
  }
</script>

<style scoped>

</style>
