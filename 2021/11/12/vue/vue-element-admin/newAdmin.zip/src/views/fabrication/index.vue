<template>
  <div class="app-container">
    <el-container style="height: 90vh;">
      <el-aside width="200px">
        <div style="height: 60px;margin-top: 20px">
          <span>在线表单制作</span>
        </div>
        <el-row class="tac">
          <el-col :span="24">
            <!--
              default-active:当前激活的菜单
              @open：展开指定的 sub-menu
              @close：收起指定的 sub-menu
              asideNav:循环遍历data中的这个内容
             -->
            <el-menu
              :key="index"
              @close="handleClose"
              @open="handleOpen"
              class="el-menu-vertical-demo"
              default-active="2" v-for="(item,index) in asideNav">
              <el-submenu :index="'1-' + index">
                <template slot="title">
                  <i :class="item.icon"></i>
                  <span>{{item.name}}</span>
                </template>
                <template v-if="item.children">
                  <el-menu-item :index="`${indexCh}`" :key="indexCh"
                                @click="childrenClick(itemCh)" v-for="(itemCh,indexCh) in item.children">
                    <div style="width: 100%;display: flex;justify-content: space-around">
                      <i :class="itemCh.icon" style="line-height: 50px"></i>
                      {{itemCh.name}}
                    </div>
                  </el-menu-item>
                </template>
              </el-submenu>
            </el-menu>
          </el-col>
        </el-row>
      </el-aside>
      <el-main class="" style="display: flex;justify-content: center;align-items: center;position: relative">
        <div class="main-phone" ref="content">
          <el-form :model="dynamicValidateForm" class="demo-dynamic" label-width="100px" ref="dynamicValidateForm">
            <el-form-item
              :key="domain.key"
              :label="domain.fromName"
              :prop="'domains.' + index + '.value'"
              v-for="(domain, index) in dynamicValidateForm.domains">
              <el-input v-model="domain.value" ></el-input>
              <el-button @click.prevent="removeDomain(domain)">删除</el-button>
            </el-form-item>
            <el-form-item>
              <el-button @click="submitForm('dynamicValidateForm')" type="primary">提交</el-button>
              <el-button @click="resetForm('dynamicValidateForm')">重置</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="main-phone-active">
          <div>
            输入框宽度：
            <el-input
              placeholder="10"
              suffix-icon="el-icon-date">
            </el-input>
          </div>
        </div>
      </el-main>
    </el-container>-
    <el-dialog
      :visible.sync="centerDialogVisible"
      center
      title="提示"
      width="30%">
      <div>
        <el-form :model="ruleFormName" class="demo-ruleForm" label-width="100px"
                 status-icon>
          <el-form-item label="表名" prop="pass">
            <el-input autocomplete="off" v-model="ruleFormName.fromName"></el-input>
          </el-form-item>
          <el-form-item label="名称" prop="checkPass">
            <el-input autocomplete="off" v-model="ruleFormName.name"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span class="dialog-footer" slot="footer">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button @click="addFromConten" type="primary">确 定</el-button>
  </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: 'fabrication',
    data() {
      return {
        // 添加之前填框
        ruleFormName: {
          fromName: '',
          name: ''
        },
        fromType:'',
        centerDialogVisible: false,
        dynamicValidateForm: {
          domains: [{
            value: '',
            fromName:''
          }]
        },
        // 表单提交内容
        ruleForm: {
          name: ''
        },
        // nav 导航
        asideNav: [
          {
            name: '背景图',
            icon: 'el-icon-edit'
          },
          {
            name: '背景图',
            icon: 'el-icon-edit'
          },
          {
            name: '表单',
            children: [
              {
                name: '输入框',
                icon: 'el-icon-edit',
                type: 'input',
                index: 1
              },
              {
                name: '单选框',
                icon: 'el-icon-edit'
              },
              {
                name: '多选框',
                icon: 'el-icon-edit'
              },
              {
                name: '多行文字输入框',
                icon: 'el-icon-edit'
              },
              {
                name: '提交按钮',
                icon: 'el-icon-edit'
              },
              {
                name: '重置按钮',
                icon: 'el-icon-edit'
              }
            ]
          }
        ]
      }
    },
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath)
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath)
      },
      abcd() {
        console.log(this.dynamicValidateForm)
      },

      // 点击提交
      submitForm(formName) {
        console.log(formName)
        this.$refs[formName].validate((valid) => {

          if (valid) {
            alert('submit!')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      // 点击重置
      resetForm(formName) {
        this.$refs[formName].resetFields()
      },
      // 点击删除
      removeDomain(item) {
        var index = this.dynamicValidateForm.domains.indexOf(item)
        if (index !== -1) {
          this.dynamicValidateForm.domains.splice(index, 1)
        }
      },
      // 点击添加的弹框
      childrenClick(item) {
        this.centerDialogVisible = true
        this.fromType = item
      },
      addFromConten(){
        // 逻辑
        if (this.fromType.type == 'input') {
          this.dynamicValidateForm.domains.push({
            value: this.ruleFormName.name,
            fromName: this.ruleFormName.fromName,
            key: Date.now()
          })
        }
        this.ruleFormName.name = ''
        this.ruleFormName.fromName = ''
        this.centerDialogVisible = false
        console.log(/^[a-zA-Z]+$/)
      }
    }
  }
</script>

<style scoped>
  .main-phone-active {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 300px;
    height: 200px;
    background-color: #20a0ff;
  }

  .main-phone {
    width: 375px;
    height: 750px;
    border: 2px solid #FFFFFF;
  }

  .el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
  }

  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 60px;
  }

  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 160px;
  }

  body > .el-container {
    margin-bottom: 40px;
  }

  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }

  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>
