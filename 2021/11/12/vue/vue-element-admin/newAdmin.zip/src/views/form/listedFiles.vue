<template>
  <div class="app-container">
    <div class=" grid-content bg-purple img-list" v-for="(item,index) in filesList">
      <div class="img-list-edit">
        <i @click="deleteFile(item)" class="el-icon-delete"></i>
        <i @click="lookFile(item)" class="el-icon-zoom-in"></i>
        <a :href="item.url" :download="item.url" target="_blank">
          <i  class="el-icon-download"></i>
        </a>
      </div>
      <img :src="item.urlImage"
           style="width: 100%">
    </div>
    <el-dialog :visible.sync="dialogVisible" :title="dialogImageUrl.originalname">
    <div>
      <div>链接：{{dialogImageUrl.url}}</div>
    </div>
      <br/>
      <img :src="dialogImageUrl.url" alt="" width="100%" v-if="isShow == 'image'">
      <audio :src="dialogImageUrl.url" controls  width="100%" v-if="isShow == 'audio'">
        浏览器不支持此插件
      </audio>
      <video :src="dialogImageUrl.url" controls  width="100%" v-if="isShow == 'video'">
        浏览器不支持此插件
      </video>
    </el-dialog>
  </div>
</template>

<script>
  import { getUpFileList,getDeleteFile,getUpFileUpload } from '@/api/uploadFile'

  export default {
    name: 'listedFiles',
    data() {
      return {
        // 显示图片的信息
        isShow:'',
        // 图片地址
        dialogImageUrl:'',
        // 弹框是否显示
        dialogVisible:false,
        filesList: [],

      }
    },
    created() {
      this.init()
    },
    methods: {
      init() {
        this.getUpFileList()
      },
      getUpFileList() {
        getUpFileList().then(res => {
          res.data.forEach(item => {
            let typeName = item.mimetype.split('/')[0]
            if(typeName == 'image'){
              item.urlImage =  item.url
              item.isShow = 'image'
            }else if(typeName == 'audio'){
              item.urlImage = 'http://localhost:3000//images/shipin.png'//换成线上地址
              item.isShow = 'audio'
            }else if(typeName == 'video'){
              item.urlImage = 'http://localhost:3000//images/shipin.png'//换成线上地址
              item.isShow = 'video'
            }else {
              item.urlImage = 'http://localhost:3000//images/wenjian.png'//换成线上地址
              item.isShow = ''
            }
          })
          this.filesList = res.data
        })
      },
      //删除
      deleteFile(item) {
        this.$confirm('删除图片不可恢复，是否删除图片', '删除图片', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getDeleteFile(item).then(res => {
            if(res.code == 20000){
              this.getUpFileList()
            }
          })
        }).catch(()=> {
          this.$message({
            type: 'info',
            message: rej.message
          })
        })

      },
      downloadFile(item) {
        getUpFileUpload(item).then(res => {
          console.log(res)
        })
      },
      lookFile(item){
        console.log(item)
        this.isShow = item.isShow
        this.dialogVisible = true
        this.dialogImageUrl = item
      },
    }
  }
</script>

<style scoped>
  .app-container {
    display: flex;
    flex-wrap: wrap;
  }

  .img-list-edit {
    position: absolute;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-around;
    font-size: 24px;
    color: #FFFFFF;
    opacity: 0;
  }

  .img-list:hover .img-list-edit {
    background-color: rgba(0, 0, 0, .5);
    z-index: 99;
    opacity: 1;
    transition-duration: .5s;
  }

  .img-list {
    width: 148px;
    border-radius: 4px;
    overflow: hidden;
    height: 148px;
    position: relative;
    border: 1px solid rgba(0, 0, 0, .8);
    margin: 10px 10px;
  }

  .img-list img {
    height: auto;
  }
</style>
