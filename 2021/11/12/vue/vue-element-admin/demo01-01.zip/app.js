/**
 * 导入模块
 */
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

/**
 * 导入自定义的路由模块
 * 
 *  */

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var tableRouter = require('./routes/table');
var newsRouter = require('./routes/news');
var uploadimgRouter = require('./routes/uploadimg');
var fileEditRouter = require('./routes/uploadFile');
var goodsRouter = require('./routes/goods')

var app = express();


// 开放一个views端口 找jade文件app.set('view engine', 'jade');需要查文档
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');


// 中间件文件
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(__dirname + '/uploads'))
app.use('/fileType', express.static(__dirname + '/fileType'))

// 请求中间件判断是否登录状态
app.use(function (req, res, next) {
  if (req.url == '/users/login'){
    console.log(req.url)
    next()
    return
  }
  if (req.cookies.token == 'a4c45ric80hkca6du6hkk0ii7k'){
    /**
     * 先判断是否存在。存在：next(),不存在else{}
     * 在if内继续判断token时间过，直接判断过期，过期return 返回一个登录的url和清除token的信息，前端做跳转登录页面
     * 
     */
    console.log(req.cookies.token)
    console.log(usersRouter)
    next()
  }else{
    res.json({
      status: 20000,
      massage: '当前未登录',
      data: '/users/login'
    })
  }
})

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/goods',goodsRouter)
app.use('/table', tableRouter)
app.use('/news', newsRouter)
app.use('/uploadimg', uploadimgRouter)
app.use('/uploadFile', fileEditRouter)

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
