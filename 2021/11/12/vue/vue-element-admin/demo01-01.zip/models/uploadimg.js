// 导入可接收图片的插件
const multer = require('multer')

const fs = require('fs')

// 插件字写 格式化时间
const { getNowFormatDate } = require('../common/dateTime')
let time = getNowFormatDate('')

// 定义图片中间件的内容
const storage = multer.diskStorage({
  // 定义保存图片的地址
  destination: function (req, file, cb) {
    // 某个文件夹下的日期文件下的图片目录
    let path = __dirname + '/../uploads/' + time
    // 返回这个目录
    file.time = time
    let ifFile = fs.existsSync(path)
    
    if (ifFile){
      cb(null, path)
    }else{
      fs.mkdirSync(path)
      cb(null, path)
    }
  },

  // 定义保存图片的名称，默认没有后缀名，需要添加后缀名
  filename: function (req, file, cb) {
    let suffix = file.originalname.split('.')
    suffix = suffix[suffix.length - 1]
    // console.log(suffix)

    // 图片使用
    // let mimetype = file.mimetype.split('/')[1]
    cb(null, file.fieldname + '-' + Date.now() + time + '.' + suffix)
  }
})
module.exports = multer({ storage })