

const express = require('express')

// 导入文件系统
const fs = require('fs')

// 导入路径
const path = require('path')

// 压缩图片
var images = require("images");

// 导入压缩图片
const imageCompress = require('../img.js')

// 使用Router
const router = express.Router()

const upload = require('../models/uploadimg')

router.post('/', upload.single('files'), async (req, res) => {
  try {
    let file = req.file
    // 返回的线上地址
    file.url = `http://localhost:3000/uploads/${file.time}/${file.filename}`
    // 根据传来的参数进行压缩，在返回地址上下都行，是直接操作图片文件，跟返回的信息是没有关系的
    // 压缩图片的比例 -  图片路径 - 图片宽高 - 保存路径(如果是相同路径直接覆盖) - 保存质量
    // images(file.path).size(500).save(file.path, { quality: 90})
    // 返回json数据
    res.json({
      code: 20000,
      data: file,// 返回数据的名称
    })
  } catch (e) {
    console.log(e)
  }
})


router.delete('/', async (req, res) => {
  try {
    let body = req.body
    let name = body.filename
    fs.unlinkSync(path.join(__dirname, '../uploads/' + body.time +'/' + name))
    res.json({
      code: 20000,
      data: [],// 返回数据的名称
      message: '文件已删除',// 返回数据的名称
    })
    
  } catch (e) {
    console.log('错误')
    console.log(e)
  }
})

// 批量压缩图片
router.get('/compress',async (req,res)=>{
  try{
    
    imageCompress('uploads')
  } catch (e) {
    console.log('错误')
    console.log(e)
  }
})

module.exports = router;



