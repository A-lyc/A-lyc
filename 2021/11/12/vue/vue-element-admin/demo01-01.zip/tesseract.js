const { createWorker } = require('tesseract.js');

const worker = createWorker();

let name = async() => {
 await worker.load();
 console.log('1') 
 await worker.loadLanguage('eng');
  console.log('2') 
  await worker.initialize('eng');
  console.log('3') 
  const { data: { text } } = await worker.recognize('https://tesseract.projectnaptha.com/img/eng_bw.png');
  console.log('4') 
  console.log(text);
  await worker.terminate();
  console.log('5') 
}
name()
console.log('6')

