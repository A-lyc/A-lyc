const xlsxCompress = require('./xlsx');
async function name(params) {
  xlsxCompress().then(res => {
   console.log('---- 1 ----')
   console.log(res)
   console.log('---- 2 ----')
 })
  
} 

name()