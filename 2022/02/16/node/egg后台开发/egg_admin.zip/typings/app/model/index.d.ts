// This file is created by egg-ts-helper@1.26.0
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBanner = require('../../../app/model/banner');
import ExportBusiness = require('../../../app/model/business');
import ExportBusinessClass = require('../../../app/model/businessClass');
import ExportFirm = require('../../../app/model/firm');
import ExportNav = require('../../../app/model/nav');
import ExportNews = require('../../../app/model/news');
import ExportProduct = require('../../../app/model/product');
import ExportTestCrud = require('../../../app/model/testCrud');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Banner: ReturnType<typeof ExportBanner>;
    Business: ReturnType<typeof ExportBusiness>;
    BusinessClass: ReturnType<typeof ExportBusinessClass>;
    Firm: ReturnType<typeof ExportFirm>;
    Nav: ReturnType<typeof ExportNav>;
    News: ReturnType<typeof ExportNews>;
    Product: ReturnType<typeof ExportProduct>;
    TestCrud: ReturnType<typeof ExportTestCrud>;
    User: ReturnType<typeof ExportUser>;
  }
}
