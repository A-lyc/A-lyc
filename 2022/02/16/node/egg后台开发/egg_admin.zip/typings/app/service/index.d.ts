// This file is created by egg-ts-helper@1.26.0
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportBanner = require('../../../app/service/banner');
import ExportBusiness = require('../../../app/service/business');
import ExportBusinessClass = require('../../../app/service/businessClass');
import ExportFirm = require('../../../app/service/firm');
import ExportLogin = require('../../../app/service/login');
import ExportNav = require('../../../app/service/nav');
import ExportNews = require('../../../app/service/news');
import ExportProduct = require('../../../app/service/product');
import ExportTestCrud = require('../../../app/service/testCrud');

declare module 'egg' {
  interface IService {
    banner: AutoInstanceType<typeof ExportBanner>;
    business: AutoInstanceType<typeof ExportBusiness>;
    businessClass: AutoInstanceType<typeof ExportBusinessClass>;
    firm: AutoInstanceType<typeof ExportFirm>;
    login: AutoInstanceType<typeof ExportLogin>;
    nav: AutoInstanceType<typeof ExportNav>;
    news: AutoInstanceType<typeof ExportNews>;
    product: AutoInstanceType<typeof ExportProduct>;
    testCrud: AutoInstanceType<typeof ExportTestCrud>;
  }
}
