// This file is created by egg-ts-helper@1.26.0
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBanner = require('../../../app/controller/banner');
import ExportBusiness = require('../../../app/controller/business');
import ExportBusinessClass = require('../../../app/controller/businessClass');
import ExportFirm = require('../../../app/controller/firm');
import ExportHome = require('../../../app/controller/home');
import ExportLogin = require('../../../app/controller/login');
import ExportNav = require('../../../app/controller/nav');
import ExportNews = require('../../../app/controller/news');
import ExportProduct = require('../../../app/controller/product');
import ExportTestCrud = require('../../../app/controller/testCrud');
import ExportTransaction = require('../../../app/controller/transaction');
import ExportUpload = require('../../../app/controller/upload');

declare module 'egg' {
  interface IController {
    banner: ExportBanner;
    business: ExportBusiness;
    businessClass: ExportBusinessClass;
    firm: ExportFirm;
    home: ExportHome;
    login: ExportLogin;
    nav: ExportNav;
    news: ExportNews;
    product: ExportProduct;
    testCrud: ExportTestCrud;
    transaction: ExportTransaction;
    upload: ExportUpload;
  }
}
