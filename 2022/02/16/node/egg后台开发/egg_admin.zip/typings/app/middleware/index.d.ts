// This file is created by egg-ts-helper@1.26.0
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportChecktoken = require('../../../app/middleware/checktoken');
import ExportLogin = require('../../../app/middleware/login');
import ExportRegister = require('../../../app/middleware/register');

declare module 'egg' {
  interface IMiddleware {
    checktoken: typeof ExportChecktoken;
    login: typeof ExportLogin;
    register: typeof ExportRegister;
  }
}
