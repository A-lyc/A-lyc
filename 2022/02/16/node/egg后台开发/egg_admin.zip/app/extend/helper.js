
/*
* 验证数据库中有没有这个用户
* @param Array alluserList 数据库获取的全部用户列表
* @param Array phone 用户手机号
* return bool
* For: exports.check_mobile([],'13859548575') => true:没有这个用户，false：有这个用户
* */
exports.user_info = async (alluserList = [],phone = '')=> {
    console.log('我是helper的内容ctx.helper.user_info(user)',alluserList,phone)
};

/*
* 手机号码验证
* @param string mobile 手机号码
* return bool
* For: exports.check_mobile('13859548575') => true
* */
exports.check_mobile = mobile => {
    const reg = /(^1[3|4|5|7|8][0-9]{9}$)/;
    if (reg.test(mobile)) {
        return true;
    }
    return false;
};

/*
 * 验证码生成
 * @param int len 验证码长度
 * @param int width 图片宽度
 * @param int height 图片高度
 * return buffer,string 图片流,验证码文本
 */
exports.make_capcha = (len = 4, width = 100, height = 40) => {
    const img = new BMP24(width, height);
    // 白色背景
    img.fillRect(0, 0, width, height, 0xffffff);
    // 绘制圆
    img.drawCircle(rand(0, 100), rand(0, 40), rand(10, 40), rand(0, 0xeeeeee));
    // 边框
    img.drawRect(0, 0, img.w - 1, img.h - 1, rand(0, 0xeeeeee));
    img.fillRect(rand(0, 100), rand(0, 40), rand(10, 35), rand(10, 35), rand(0, 0xeeeeee));
    img.drawLine(rand(0, 100), rand(0, 40), rand(0, 100), rand(0, 40), rand(0, 0xeeeeee));

    // 画曲线
    const w = img.w / 2;
    const h = img.h;
    const color = rand(0, 0xeeeeee);
    const y1 = rand(-5, 5); // Y轴位置调整
    const w2 = rand(10, 15); // 数值越小频率越高
    const h3 = rand(4, 6); // 数值越小幅度越大
    const bl = rand(1, 5);
    for (let i = -w; i < w; i += 0.1) {
        const y = Math.floor(h / h3 * Math.sin(i / w2) + h / 2 + y1);
        const x = Math.floor(i + w);
        for (let j = 0; j < bl; j++) {
            img.drawPoint(x, y + j, color);
        }
    }

    const p = 'ABCDEFGHKMNPQRSTUVWXYZ3456789';
    let str = '';
    for (let i = 0; i < len; i++) {
        str += p.charAt(parseInt(Math.random() * p.length));
    }
    // 绘制文本
    const fonts = [BMP24.font8x16, BMP24.font12x24, BMP24.font16x32];
    let x = 15,
        y = 8;
    for (let i = 0; i < str.length; i++) {
        const f = fonts[parseInt(Math.random() * fonts.length)];
        y = 8 + rand(-10, 10);
        img.drawChar(str[i], x, y, f, rand(0, 0x333344));
        x += f.w + rand(2, 8);
    }
    return { img: img.getFileData(), text: str };
};
