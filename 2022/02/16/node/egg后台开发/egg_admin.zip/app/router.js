'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller, io } = app;
  // 首页 - 只有上传文件
  router.get('/',controller.home.index);
  // 点击登录 
  router.post('/login', controller.login.login);
  // 获取用户信息
  router.get('/user/info', controller.login.info);
  // 获取相应权限的功能
  router.get('/transaction/list', controller.transaction.list);
  // 注册用户 有验证这个用户是不是已注册过的
  router.post('/register',app.middleware.register(), controller.login.create);
  // 创建新闻
  router.post('/news/create_news', app.middleware.checktoken(), controller.news.create);
  // 新闻列表
  router.get('/news/list', app.middleware.checktoken(), controller.news.list);
  // s删除新闻列表
  router.get('/news/destroy', app.middleware.checktoken(), controller.news.destroy);
  // 获取单条新闻-编辑使用
  router.get('/news/fetchArticle', app.middleware.checktoken(), controller.news.findAllOne);
  // 更新新闻
  router.put('/news/update', app.middleware.checktoken(), controller.news.update);


  // 业务领域
  router.post('/business/create_news', app.middleware.checktoken(), controller.business.create);
  // 业务领域列表
  router.get('/business/list', app.middleware.checktoken(), controller.business.list);
  // s删除业务领域列表
  router.get('/business/destroy', app.middleware.checktoken(), controller.business.destroy);
  // 获取单条业务领域-编辑使用
  router.get('/business/fetchArticle', app.middleware.checktoken(), controller.business.findAllOne);
  // 更新业务领域
  router.put('/business/update', app.middleware.checktoken(), controller.business.update);
// 搜索
  router.get('/business/search', app.middleware.checktoken(), controller.business.search);


  // 产品中心
  router.post('/product/create_news', app.middleware.checktoken(), controller.product.create);
  // 产品中心列表
  router.get('/product/list', app.middleware.checktoken(), controller.product.list);
  // s删除产品中心列表
  router.get('/product/destroy', app.middleware.checktoken(), controller.product.destroy);
  // 获取单条产品中心-编辑使用
  router.get('/product/fetchArticle', app.middleware.checktoken(), controller.product.findAllOne);
  // 更新产品中心
  router.put('/product/update', app.middleware.checktoken(), controller.product.update);

  

  // 导航增删改查 app.middleware.checktoken(), 
  router.resources('/nav', controller.nav)
  
  // 业务分类增删改查 app.middleware.checktoken(), 
  router.resources('/business_nav', controller.businessClass)

  // banenr增删改查 app.middleware.checktoken(), 
  router.resources('/banner', controller.banner)


  // 关于我们
  router.resources('/api/about', controller.firm)
  // // 领军市场
  // router.get('/api/bazaar', controller.firm.bazaar)
  // // 联系方式
  // router.get('/api/contact', controller.firm.contact)

  // // 发展战略
  // router.get('/api/develop', controller.firm.develop)
  // // 获得荣誉
  // router.get('/api/honor', controller.firm.honor)










  /// web
  // 业务领域页面，跳转通过传输业务分类来判断
  router.get('/business/:business', controller.business.business)
 // 业务领域详情页面，
  router.get('/business_active/:id', controller.business.business_active)
// 产品页面
  router.get('/product', controller.product.product)
  // 产品详情也
  router.get('/product_active/:id', controller.product.product_active)
  // 咨询中心
  router.get('/news', controller.news.news)
  // 咨询中心详情
  router.get('/news_active/:id', controller.news.news_active)

 // 关于我们
  router.get('/about', controller.home.about)
// 领军市场
  router.get('/bazaar', controller.home.bazaar)
  // 联系方式
  router.get('/contact', controller.home.contact)

  // 发展战略
  router.get('/develop', controller.home.develop)
  // 获得荣誉
  router.get('/honor', controller.home.honor)






  // 查询用户 注册添加用户
  // router.resources('login','/login',app.middleware.register(), controller.login);
  // 增删改查，没有页面
  router.resources('testCrud', '/testCrud',app.middleware.checktoken(), controller.testCrud) // 暂时不加中间件app.middleware.checktoken()
  // 单个文件上传 上传都不是自动生成文件夹的,app.middleware.checktoken()
  router.post('/upload', controller.upload.upload)
  // 单个文件上传 上传是自动生辰文件夹的 - js上传,app.middleware.checktoken()
  router.post('/uploadFile', controller.upload.uploadFile)
  // socket, 指向app/io/controller/chat.js的index方法
  io.of('/').route('chat', app.io.controllers.chat.index);
};
