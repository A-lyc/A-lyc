module.exports = app => {
  const { STRING, DATE } = app.Sequelize
  // 默认情况下Sequelize将自动传递所有的模型名称（define的第一个参数）转换为复数
  // 这里会自动生成一个ID,数据库中有一个字段的名字叫做name
  const Business = app.model.define('businesses', {
    content:STRING,
    content_short:STRING,
    display_time:DATE,
    image_uri:STRING,
    source_uri:STRING,
    status:STRING,
    title:STRING,
    business_class:STRING,
  });
  return Business
}
