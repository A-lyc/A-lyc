/* header 点击展开关闭手机端的 */
// 手机端点击展开的一个
$('.header-phone').click(function () {
  $('.header-phone-nav').addClass('header-phone-nav-active')
})
// 点击关闭
$('#close-phone').click(function () {
  $('.header-phone-nav').removeClass('header-phone-nav-active')
})

/* 获取屏幕宽度 */
let win_width = $(window).width()
let seiper_sum = 4
if((win_width*1)<1000){
  seiper_sum = 2
}
/* 获取屏幕高度 */
let win_hight = $(window).height()
console.log(win_hight)
if(win_hight<1000){
  $('#news-active').attr('style','height:100vh')
}
/* swiper */
var mySwiper = new Swiper('.swiper2', {
  autoplay: true,//可选选项，自动滑动
  initialSlide: 0,// 第几个开始
  speed: 3000,//slider自动滑动开始到结束的时间（
  grabCursor: true,// 设置为true时，鼠标覆盖Swiper时指针会变成手掌形状
  autoplay: {
    delay: 1000
  },
  loop : true,
})
var swiper = new Swiper(".swiper3", {
  slidesPerView: seiper_sum,
  spaceBetween: 30,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});



/* 产品详情 */
$('.classify').click(function (event) {
  let is_show_active = $(this)[0].dataset.name
  $('.classify').each(function (item,index){
    $(this).removeClass('auxiliary-color-bg')
    $(this).removeClass('text-white')
  })
  $('.class_active').each(function (item,index){
    $(this).removeClass('d-block')
  })

  $(this).addClass('auxiliary-color-bg')
  $(this).addClass('text-white')
  $('#'+ is_show_active).addClass('d-block')
})
/* 返回顶部 */
$('#win-top').click(function(){
  $('html ,body').animate({scrollTop: 0}, 1000);
  return false;
});


$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

/* 例子 */
// let nav = new Array(...$('.header-nav-item'))
// nav.forEach(function (item,index){
//   console.log(item)
// })
// 点击导航PC
$('.header-nav-item').click(function (event) {
  $('.header-nav-item').each(function (item,index){
    $('.header-nav-item').removeClass('active')
  })
  $(this).addClass('active')
})




if (window.location.pathname == '/') {
  let nav = $('.header-nav-item')[0]
  $(nav).addClass('active')
}
if (window.location.pathname == '/business/zhihuishequ') {
  let nav = $('.header-nav-item')[1]
  $(nav).addClass('active')
}
if (window.location.pathname == '/product') {
  let nav = $('.header-nav-item')[2]
  $(nav).addClass('active')
}
if (window.location.pathname == '/news') {
  let nav = $('.header-nav-item')[3]
  $(nav).addClass('active')
}
if (window.location.pathname == '/about') {
  let nav = $('.header-nav-item')[4]
  $(nav).addClass('active')
}
if (window.location.pathname == '/contact') {
  let nav = $('.header-nav-item')[5]
  $(nav).addClass('active')
}
