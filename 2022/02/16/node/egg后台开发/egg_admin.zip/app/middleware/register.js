
function checktoken(){
    // 返回的本身有两个参数
    return async function(ctx,next){
        try{
            let user_info = ctx.request.body
                // 获取所有用户
                const data = await ctx.service.login.find_user()
                // 转成数组
                let userAll = JSON.parse(JSON.stringify(data))
                // 查看是否存在
                let index = userAll.findIndex(item=>{return item.phone == user_info.phone})
            // 用户有注册  else  用户没有注册
            if (index != '-1') {
                ctx.body = { code: 400,message:'手机号已注册，请直接登录', }
            } else {
                await next()
            }
            // 以上报错的时候
        }catch(e){
            await next()
        }
    }
}
module.exports = checktoken