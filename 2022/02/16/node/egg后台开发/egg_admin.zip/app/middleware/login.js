
function checktoken(){
    // 返回的本身有两个参数
    return async function(ctx,next){
        try{
            // 获取token
            let token = ctx.request.header.token
            // 校验token
            let ddecode = ctx.app.jwt.verify(token, ctx.app.config.jwt.secret)
            // 获取所有用户
            const data = await ctx.service.login.find_user()
            // 转成数组
            let userAll = JSON.parse(JSON.stringify(data))
            // 查看是否存在
            let index = userAll.findIndex(item=>{return item.phone == ddecode.phone})
            // 存在 else 不存在
            if (index) {
                await next()
            } else {
                ctx.body = { code: 400,message:'用户不存在，请先注册用户', }
            }
            // 以上报错的时候
        }catch(e){
            ctx.body = { code: 400,...e,msg:'用户不存在', }
        }
    }
}
module.exports = checktoken