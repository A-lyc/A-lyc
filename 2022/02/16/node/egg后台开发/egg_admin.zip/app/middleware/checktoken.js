// 中间件是一个函数
// 使用的时候在router 通过app.middleware.checktoken
function checktoken(){
  // 返回的本身有两个参数
  return async function(ctx,next){
      // 获取token
      let token = ctx.request.header['x-token']
      // 校验token
      let ddecode = ctx.app.jwt.verify(token, ctx.app.config.jwt.secret)
     
      if(ddecode){
        await next()
      } else {
        
        ctx.body = { code: 400, message: '用户不存在，请先注册用户', }
      }
  }
}
module.exports = checktoken