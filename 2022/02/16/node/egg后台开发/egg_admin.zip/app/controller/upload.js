const Controller = require('egg').Controller;
const fs = require('fs');
const path = require('path');
const awaitWriteStream = require('await-stream-ready').write;// 重点在这
const sendToWormhole = require('stream-wormhole');
const dayjs = require('dayjs');

module.exports = class extends Controller {
  // 上传未指定那个文件夹
  async upload() {
    let { ctx } = this
    const stream = await this.ctx.getFileStream();
    console.log('上传的文件')
    console.log(stream)
    // 定义文件名 
    const filename = Date.now() + path.extname(stream.filename).toLocaleLowerCase();
    console.log('上传文件名')
    console.log(filename)
    // 目标文件 
    const target = path.join('app/public/upload', filename);
    console.log('目标文件')
    console.log(target)
    // 
    const writeStream = fs.createWriteStream(target);
    console.log('writeStream')
    console.log(writeStream)

    try {
      //异步把文件流 写入 
      await awaitWriteStream(stream.pipe(writeStream));
      ctx.body = {
        ...stream.fields,
        url: '/public/upload/' + filename,
      };
    } catch (err) {
      //如果出现错误，关闭管道
      await sendToWormhole(stream)
      console.log(err)
    }
  }
  // 上传指定那个文件夹
  async uploadFile() {
    let { ctx } = this
    const stream = await ctx.getFileStream();
    console.log('上传的文件')
    console.log(stream)
    // 基础的目录 
    const uplaodBasePath = 'app/public/upload';
    console.log('基础的目录')
    console.log(uplaodBasePath)
    // 生成文件名 
    const filename = `${Date.now()}${Number.parseInt(Math.random() * 1000,)}${path.extname(stream.filename).toLocaleLowerCase()}`;
    
    // 生成文件夹 
    const dirname = dayjs(Date.now()).format('YYYY/MM/DD');
    function mkdirsSync(dirname) {
      if (fs.existsSync(dirname)) {
        return true;
      } else {
        if (mkdirsSync(path.dirname(dirname))) {
          fs.mkdirSync(dirname); return true;
        }
      }
    }
    mkdirsSync(path.join(uplaodBasePath, dirname));
    // 生成写入路径
    const target = path.join(uplaodBasePath, dirname, filename);
    // 写入流
    const writeStream = fs.createWriteStream(target);
    try {
      //异步把文件流 写入
      await awaitWriteStream(stream.pipe(writeStream));
    } catch (err) {
      //如果出现错误，关闭管道
      await sendToWormhole(stream);
    }
    
    ctx.body = { stream,url:'/public/upload/'+dirname+'/'+filename }
  }
  
}
