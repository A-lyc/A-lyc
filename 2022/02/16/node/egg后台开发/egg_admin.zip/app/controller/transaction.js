'use strict';

const Controller = require('egg').Controller;

class transaction extends Controller {
  async list(){
    let {app,ctx } = this

  }
}

module.exports = transaction;