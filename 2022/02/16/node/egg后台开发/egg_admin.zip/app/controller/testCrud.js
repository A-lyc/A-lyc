const Controller = require('egg').Controller;

class textController extends Controller {
  // restful 接口
  /*
  * 查看：index
  * 添加：create
  * 删除：destroy
  * 修改：update
  */
  // 查看
  // 返回多少条
  /***
  * where: { status: 'draft', author: ['author1', 'author2'] }, // WHERE 条件
  * columns: ['author', 'title'], // 要查询的表字段
  * orders: [['created_at','desc'], ['id','desc']], // 排序方式
  * limit: 10, // 返回数据量
  * offset: 0, // 数据偏移量
  * 前台分页组件有时会需要查询全部记录数，这时可以直接使用count
  * where: {
  *    status: 1
  * }
   * 
   */
  async index() {
    let { ctx, app } = this
    // 在server中操作处理数据库中的信息，controller内只负责控制输出数据
    const data = await ctx.service.testCrud.findAll() 
    ctx.body = data

  }
  // 添加
  async create() {
    let { ctx } = this
    let a = ctx.request.body
    console.log(a)
    const data = await ctx.service.testCrud.create(a)
    ctx.body = {
      code: 200,
      message: '添加成功',
      data
    }
  }
  // 删除
  async destroy() {
    let { ctx } = this
    let id = ctx.params.id
    const data = await ctx.service.testCrud.destroy(id)
    ctx.body = {code:200,message:'删除成功'}

  }
  // 更新
  async update() {
    let { ctx } = this
    let { name, dscription} = ctx.request.body
    let id = ctx.params.id
    // 这里的name对应这数据库中的name
    const data = await ctx.service.testCrud.update({ name, dscription },id)
    ctx.body = {
      code: 200,
      message: '更新成功',
      data
    }
  }
}

module.exports = textController