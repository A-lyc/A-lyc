'use strict'; // 严格模式
// class 类 egg提供了egg Controller这个类
const Controller = require('egg').Controller;
// HomeController继承Controller
class firm extends Controller {

  // 例子
  // async index() {
  //   let { ctx, } = this
  //   console.log('data')
  //   // 在server中操作处理数据库中的信息，controller内只负责控制输出数据
  //   const data = await ctx.service.nav.findAll()
  //   if (data.length == 0) {
  //     ctx.body = { data, code: 201, message: '请先添加导航' }
  //   } else {
  //     ctx.body = { data, code: 200, message: 'ok' }
  //   }

  // }
  // 公司企业的其他接口页面
  async index() {
    const { ctx } = this;
    let name = ctx.request.query.name
    const data = await ctx.service.firm.findAll(name)
    ctx.body = { data, code: 200, message: 'ok' }
  }

  // 创建
  async create() {
    let { ctx } = this
    let res = ctx.request.body
    const data = await ctx.service.firm.create(res)
    ctx.body = {
      code: 200,
      message: '添加成功',
      data
    }
  }  
  // 更新
  async update() {
    let { ctx } = this
    let dataBody = ctx.request.body
    let name = ctx.params.id
    console.log(name)
    // 这里的name对应这数据库中的name
    const data = await ctx.service.firm.update(dataBody, name)
    ctx.body = {
      code: 200,
      message: data[0] == 1 ? '更新成功' : '选中更新',
      data
    }
  }

  async bazaar() {
    const { ctx } = this;
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('bazaar', { dataBusinessClass });
  }
  async contact() {
    const { ctx } = this;
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('contact', { dataBusinessClass });
  }
  async develop() {
    const { ctx } = this;
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('develop', { dataBusinessClass });
  }
  async honor() {
    const { ctx } = this;
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('honor', { dataBusinessClass });
  }

}
module.exports = firm;
