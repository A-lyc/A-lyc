const Controller = require('egg').Controller;

class textController extends Controller {

  // 查看
  async list() {
    let { ctx, app } = this
    // 在server中操作处理数据库中的信息，controller内只负责控制输出数据
    
    /***
* where: { status: 'draft', author: ['author1', 'author2'] }, // WHERE 条件
* columns: ['author', 'title'], // 要查询的表字段
* orders: [['created_at','desc'], ['id','desc']], // 排序方式
* limit: 10, // 返回数据量
* offset: 0, // 数据偏移量
* 前台分页组件有时会需要查询全部记录数，这时可以直接使用count
* where: {
*    status: 1
* }
 * 
 */
    const data = await ctx.service.business.findAll(ctx.request.query)
    ctx.body = {
      items: data.data,
      total: data.total,
      code: 200,
      message: 'ok',}

  }
  // 创建 新闻
  async create() {
    let { ctx } = this
    let content = ctx.request.body
    const data = await ctx.service.business.create(content)
    ctx.body = {
      code: 200,
      message: '添加成功',
      data
    }
  }
  // 删除
  async destroy() {
    let { ctx } = this
    let id = ctx.request.query.id
    const data = await ctx.service.business.destroy(id)
    ctx.body = { code: 200, message: '删除成功' }

  }
  // 更新
  async update() {
    let { ctx } = this
    let databody = ctx.request.body
    console.log(databody,databody.id)
    // 这里的name对应这数据库中的name
    const data = await ctx.service.business.update(databody.data, databody.id)
    ctx.body = {
      code: 200,
      message: '更新成功',
      data
    }
  }
  // 查看单独一条业务列表
  async findAllOne(){
    let { ctx } = this
    let id = ctx.request.query.id

    // 这里的name对应这数据库中的name
    const data = await ctx.service.business.findAllOne(id)
    ctx.body = {
      code: 200,
      message: 'ok',
      data
    }
  }

// 搜索业务列表
  async search(){
    let { ctx } = this
    let name = ctx.request.query
    console.log(name)

    // 这里的name对应这数据库中的name
    const data = await ctx.service.business.search(name)
    ctx.body = {
      code: 200,
      message: 'ok',
      items:data,
      total:data.length
    }
  }
  

  // //web页面 - 下面没有通过serve  直接操作的数库上的信息
  async business(){
    const { ctx, app } = this;
    // 获取传来的后面的参数
    const business = ctx.params.business
    // 获取全部的内容  直接操作的数库上的信息 - 可以在数据库中直接搜索({ where: { business_class:business } })
    const allbusList = await app.model.Business.findAll({order:[['display_time','desc']]})
    // business_class  找出business和business_class相等的进行返回
    let alldata = []
    allbusList.forEach(element => {
      if (element.business_class == business) {
        alldata.push(element)
      }
    })
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    let top_title = dataBusinessClass.find(item =>{
      if (item.urllink == business){
        return item
      }
    })
    await ctx.render('professional', { alldata, dataBusinessClass, business, top_title});
  }


  
  // 详情
  async business_active(){
    const { ctx, app } = this;
    // 添加了 id == business
    const business = ctx.params.id
    const id = ctx.params.id
    // 直接操作的数库上的信息
    const data = await app.model.Business.findAll({ where: { id } })
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    let top_title = dataBusinessClass.find(item => {
      if (item.id == id) {
        return item
      }
    })
    await ctx.render('professional_active', { data: data[0], business, dataBusinessClass, top_title, id});
  }

}

module.exports = textController