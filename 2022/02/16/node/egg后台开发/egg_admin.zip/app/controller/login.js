'use strict';

const Controller = require('egg').Controller;

class LoginController extends Controller {
  // 登录
  async login() {
    const { ctx } = this;
    // 解析传来的值，name和password
    let user = ctx.request.body;
    //  ctx.service(文件夹).login（js文件）.login（文件内的方法）
    let data = await ctx.service.login.login(user);
    if (data.token) {
      ctx.body = { token:data.token , code: 200, message: '成功' };// 返回json
    } else {
      ctx.body = { code: 403, message: '用户不存在' };// 返回json
    }
    // await ctx.render('index');// 跳转页面
  }
  // 查询用户 - 获取用户信息
  async info(){
    let { ctx,  } = this
    // 在server中操作处理数据库中的信息，controller内只负责控制输出数据
    const data = await ctx.service.login.find_user(ctx.request.header['x-token'])
    data.dataValues.name = data.username
    ctx.body = { data,code:200, }
    
  }
  // 注册
  async create() {
    const { ctx } = this;
    // 获取注册信息
    let user = ctx.request.body;
    let {name,phone,password} = user
    
    // 生成一个token
    let token = await ctx.app.jwt.sign(user, ctx.app.config.jwt.secret,{ expiresIn: '864000s' })
    
    user.token = token
    // 解析一个token
    // let ddecode = ctx.app.jwt.verify(token, ctx.app.config.jwt.secret)
    try {
      // 正则判断手机号
      const myreg = ctx.helper.check_mobile(phone)
       // 获取 用户列表
      const data = await ctx.service.login.find_user(token)
      // 判断是否是已注册用户
      let index = 1
      if(data.code != 200){
        index = -1
      }
      // 已注册用户是正整数，和判断是否是手机号，不是手机号走else
      if(index == '-1' && myreg){
        let userInfo = await ctx.service.login.register(user);
        // 返回数据
        ctx.body = {...userInfo};// 返回json
      }else{
        let msg = myreg?'您已注册':'手机号不正确'
        ctx.body = {code:400,msg,}
      }
    }catch (e) {
      console.log(e)
    }
    // await ctx.render('index');// 跳转页面
  }


  // 注册
  async register() {
    const { ctx } = this;
    // 获取注册信息
    let user = ctx.request.body;
    let {name,phone,password} = user
  
    let userInfo = await ctx.service.login.register(user);
    ctx.body = userInfo;// 返回json
    // await ctx.render('index');// 跳转页面
  }
  // 查询用户
  async find_user(){
  
    let { ctx, app } = this
    // 在server中操作处理数据库中的信息，controller内只负责控制输出数据
    const data = await ctx.service.login.find_user()
    ctx.body = data
  }
}

module.exports = LoginController;