const Controller = require('egg').Controller;

class textController extends Controller {

  async index() {
    let { ctx, } = this
    console.log('data')
    // 在server中操作处理数据库中的信息，controller内只负责控制输出数据
    const data = await ctx.service.banner.findAll()
    console.log(data)
    if(data.length == 0){
      ctx.body = { data, code: 201, message: '请先添加banner' }
    }else{
      ctx.body = { data, code: 200, message: 'ok' }
    }
    
  }
  // 添加
  async create() {
    let { ctx } = this
    let res = ctx.request.body
    console.log(res)
    const data = await ctx.service.banner.create(res)
    ctx.body = {
      code: 200,
      message: '添加成功',
      data
    }
  }
  // 删除
  async destroy() {
    let { ctx } = this
    let id = ctx.params.id
    console.log('ctx')
    console.log(ctx.params)
    const data = await ctx.service.banner.destroy(id)
    ctx.body = { code: 200, message: '删除成功', data }

  }
  // 更新
  async update() {
    let { ctx } = this
    let { name, dscription } = ctx.request.body
    let id = ctx.params.id
    // 这里的name对应这数据库中的name
    const data = await ctx.service.banner.update({ name, dscription }, id)
    ctx.body = {
      code: 200,
      message: data[0] == 1 ? '更新成功' : '选中更新',
      data
    }
  }
}

module.exports = textController