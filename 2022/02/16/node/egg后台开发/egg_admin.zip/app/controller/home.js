'use strict'; // 严格模式
// class 类 egg提供了egg Controller这个类
const Controller = require('egg').Controller;
// HomeController继承Controller
class HomeController extends Controller {
  // 首页展示
  async index() {
    const { ctx } = this;
    // 获取banner
    const banner = await ctx.service.banner.findAll()
    // 应用领域
    const databusiness = await ctx.service.business.findAll({ limit: 10, page:1})
    // 咨询
    const datanews = await ctx.service.news.findAll({ limit: 10, page: 1 })
    // 产品
    const dataproduct = await ctx.service.product.findAll({ limit: 10, page: 1 })
    // 分类
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    // 公司简介
    let name = 'about'
    const dataabout = await ctx.service.firm.findAll(name)

    await ctx.render('index', { databusiness, datanews, dataproduct, dataBusinessClass, banner, dataabout});
  }


  // 打开其他的页面写在了home中了
  async about() {
    const { ctx } = this;
    let name = 'about'
    const data = await ctx.service.firm.findAll(name)
    const dataBusinessClass = await ctx.service.businessClass.findAll()
  
    await ctx.render('about', { data: data.dataValues, dataBusinessClass });
  }
  async bazaar() {
    const { ctx } = this;
    let name = 'bazaar'
    const data = await ctx.service.firm.findAll(name)
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    
    await ctx.render('bazaar', { dataBusinessClass, data: data.dataValues });
  }
  async contact() {
    const { ctx } = this;
    let name = 'contact'
    const data = await ctx.service.firm.findAll(name)
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('contact', { dataBusinessClass, data: data.dataValues });
  }
  async develop() {
    const { ctx } = this;
    let name = 'tactic'
    const data = await ctx.service.firm.findAll(name)
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('develop', { dataBusinessClass, data: data.dataValues });
  }
  async honor() {
    const { ctx } = this;
    let name = 'honor'
    const data = await ctx.service.firm.findAll(name)
    const dataBusinessClass = await ctx.service.businessClass.findAll()
    await ctx.render('honor', { dataBusinessClass, data: data.dataValues });
  }
}
module.exports = HomeController;
