// app/io/middleware/filter.js

const await = require("await-stream-ready/lib/await");

// 这个中间件的作用是将接收到的数据再发送给客户端
module.exports = app => {
    return async (ctx, next) => {
        let data = ctx.packet[1]
        data.message = data.message + '- io'
        data.dscription = data.dscription + '- io'
        console.log('packet:',ctx.packet );
        // ctx.socket.emit('res', ctx.packet[1].message);
        await next();
    };
};