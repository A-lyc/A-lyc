'use strict';

const Controller = require('egg').Controller;

class DefaultController extends Controller {
  async index() {
    const {ctx,app } = this;
    const message = ctx.args[0];
    console.log(message)
    await ctx.service.testCrud.create({ name:message.message, dscription:message.dscription })
    const data = await ctx.service.testCrud.findAll() 
    console.log('chat 控制器打印', message);
    // controller 中
    // 发送给自己
    ctx.socket.emit('eventName', 'value发送给自己');
    // 发送给除了自己外的所有人
    ctx.socket.broadcast.emit('eventName', 'value发送给除了自己外的所有人');
    // 发送给所有人，包括自己
    ctx.server.sockets.emit('eventName', 'value发送给所有人，包括自己');
    await ctx.server.sockets.emit('res', {...message,data});
  }
}

module.exports = DefaultController;