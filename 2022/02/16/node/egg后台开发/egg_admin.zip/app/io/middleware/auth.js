const await = require("await-stream-ready/lib/await");

module.exports = app => {
    return async (ctx,next) => {
        console.log('中间件 auth!');
        ctx.socket.emit('res', '链接成功立马发送这个信息!');
        console.log('end 中间件 auth!');
        await next();
        console.log('disconnection!');
    };
};