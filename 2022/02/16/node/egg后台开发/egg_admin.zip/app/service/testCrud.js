const Service = require('egg').Service;
class UserService extends Service {
  async create(data){
    let { app } = this
    let res = await app.model.TestCrud.create(data)
    return res.dataValues
  }
  async destroy(id){
    let { app } = this
    let res = await app.model.TestCrud.destroy({ where: { id } })
    return res
  }
  async update(data,id){
    let { app } = this
    let res = await app.model.TestCrud.update(data, { where: { id } })
    return res.dataValues
  }
  async findAll() {
    let { app } = this
    // 返回多少条
    /***
    * where: { status: 'draft', author: ['author1', 'author2'] }, // WHERE 条件
    * columns: ['author', 'title'], // 要查询的表字段
    * orders: [['created_at','desc'], ['id','desc']], // 排序方式
    * limit: 10, // 返回数据量
    * offset: 0, // 数据偏移量
    * 前台分页组件有时会需要查询全部记录数，这时可以直接使用count
    * where: {
    *    status: 1
    * }
     * 
     */
    let data = await app.model.TestCrud.findAll()
    return data
  }
}
module.exports = UserService;