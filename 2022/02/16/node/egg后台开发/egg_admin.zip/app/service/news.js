const Service = require('egg').Service;
class UserService extends Service {
  async create(data) {
    let { app } = this
    let res = await app.model.News.create(data)
    return res.dataValues
  }
  async destroy(id) {
    let { app } = this
    let res = await app.model.News.destroy({ where: { id } })
    return res
  }
  async update(data, id) {
    let { app } = this
    let res = await app.model.News.update(data, { where: { id } })
    return res.dataValues
  }
  async findAll(where) {
    let { app } = this
    // 返回多少条
    /***
    * where: { status: 'draft', author: ['author1', 'author2'] }, // WHERE 条件
    * columns: ['author', 'title'], // 要查询的表字段
    * order: [['created_at','desc'], ['id','desc']], // 排序方式
    * limit: 10, // 返回数据量
    * offset: 0, // 数据偏移量
    * 前台分页组件有时会需要查询全部记录数，这时可以直接使用count
    * where: {
    *    status: 1
    * }
     * 
     */
    // 获取全部的数据 / 传来的一个显示条数
   
    // let data = await app.model.News.findAll({limit: where.limit*1, offset: (where.page - 1) * where.limit})
    let data = await app.model.News.findAll({limit: where.limit*1, offset: (where.page - 1) * where.limit,order:[['display_time','desc']]})
    let dataList = await app.model.News.findAll()
    let total = dataList.length
    return { data, total: Math.ceil(total)}
  }
  // 查询单独一条的
  async findAllOne(where) {
    let { app } = this
    let data = await app.model.News.findAll({ where:{ id: where }})
    return data[0]
  }
}
module.exports = UserService;