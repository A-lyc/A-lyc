'use strict';

const await = require('await-stream-ready/lib/await');

const Service = require('egg').Service;

class LoginService extends Service {
    async login(user) {
        let {  ctx } = this
        let token = await ctx.app.jwt.sign(user, ctx.app.config.jwt.secret, { expiresIn: '864000s' })
        // 查找所有用户 - 用了下面的方法
        const data = await ctx.service.login.find_user(token)
        if (user.username == data.username && user.password == user.password) {
            // 生成token
            return { token,data};
        }else{
            return false
        }  
    }
    // 查找所有用户
    async find_user(token){
        let { app, ctx } = this
        let ddecode =await ctx.app.jwt.verify(token, ctx.app.config.jwt.secret)
        let data = await app.model.User.findAll()
        let user_data = {
            message:'',
            code:403,
        }
        data.forEach((element) => {
            if (element.username == ddecode.username && element.password == ddecode.password){
                user_data = element
                user_data.dataValues.message = 'ok'
                user_data.dataValues.code = 200
            }else{
                user_data.message = '没有找到此用户'
                user_data.code = 500
            }
        });
        return user_data
    }
    async register(data){
        let { app } = this
        try{
            let res = await app.model.User.create(data)
            return {code: 200,...data}
        }catch (e) {
            return {code: 400,name:123,e}
            // console.log(e)
        }
    }
}

module.exports = LoginService;