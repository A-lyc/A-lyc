const Service = require('egg').Service;
class navHeader extends Service {
  async create(data) {
    let { app } = this
    let res = await app.model.Banner.create(data)
    return res.dataValues
  }
  async destroy(id) {
    let { app } = this
    let res = await app.model.Banner.destroy({ where: { id } })
    return res
  }
  async update(data, id) {
    let { app } = this
    let res = await app.model.Banner.update(data, { where: { id } })
    return res
  }
  async findAll() {
    let { app } = this
    let data = await app.model.Banner.findAll()
    return data
    
    
  }
}
module.exports = navHeader;