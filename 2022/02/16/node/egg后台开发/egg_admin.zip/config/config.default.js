/* eslint valid-jsdoc: "off" */

'use strict';
const path = require('path');
/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {};

  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + '_1629506750377_562';

  // add your middleware config here
  config.middleware = [];

  // add your user config here
  const userConfig = {
    // myAppName: 'egg',
  };

  // sequelized - mysql 的配置文件
  config.sequelize = {
    // 数据库类型 是mysql
    dialect: "mysql",
    // host
    host: 'localhost',
    // 端口号
    port: '3306',
    // 用户名
    username: 'hengmaikj', 
    // 密码
    password: '123456789',
    // 数据库名
    database: 'hengmaikj',
    // 时区
    timezone: '+08:00'
  }
  // 跨站请求的伪造 不做这个会禁止 关于post请求的安全设置，// 图片上传问题
  config.security = {
    csrf: {
      enable: false,
      ignoreJSON: true,
    },
    domainWhiteList: ['http://www.hengmaikj.com'],
  }
  config.cors = {
    origin: '*', // 匹配规则  域名+端口  *则为全匹配
    allowMethods: 'GET,HEAD,PUT,POST,DELETE,PATCH',
  };
  // 配置模板引擎
  config.view = {
    // 配置视图根路径
    root: path.join(appInfo.baseDir, 'app/view'),
    // 是否缓存路径
    cache: true,
    // 配置文件默认扩展名
    defaultExtension: '.html',
    // 默认渲染模板引擎
    defaultViewEngine: 'nunjucks',
    // 文件映射配置
    mapping: {
      '.html': 'nunjucks'
    }
    
  }

  // 生成用户的token 插件时egg-jwt
  config.jwt = {
    secret: 'siyecao'
  }
  // multipart 可以接受的默认文件大小是10mb. 如果你上传一个大文件，你应该指定这个配置
  config.multipart = {
    fileSize: '50mb',
    whitelist: [
      '.png', '.jpg', '.mp4','.docx'
    ],
    mode: 'stream',
  }
  // 实时通讯
  config.io = {
    // namespace命名空间配置为/
    namespace: {
      '/': {
        //  预处理器中间件, 我们这里配置了一个auth, 进行权限判断, 它对应的文件是/app/io/middleware/auth.js, 这里可以配置多个文件, 用逗号隔开
        connectionMiddleware: ['auth'], //这里我们可以做一些权限校验之类的操作// 开始 链接的时候
        packetMiddleware: ['filter'], // 通常用于对消息做预处理，又或者是对加密消息的解密等操作
      }
    },
    // 配置redis, 非必须, 不需要的可以不配置这块, egg-socket.io内置了socket-io-redis， 在cluster模式下, 使用redis可以较为简单的实现clients/rooms等信息共享
  }
  config.cluster = {
    listen: {
      path: '',
      port: 7002,
    }
  };


  // cache-control解决这个的缓存时间问题
  config.static = {
    maxAge: 0, // in prod env, 0 in other envs
    buffer: false, // in prod env, false in other envs
  };
  config.etag = {
    weak: false,
  };
  return {
    ...config,
    ...userConfig,
  };
};
