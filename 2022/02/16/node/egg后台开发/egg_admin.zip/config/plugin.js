'use strict';

/** @type Egg.EggPlugin */
module.exports = {
  // had enabled by egg
  static: {
    enable: true,
     package: 'egg-static',
  },
  // mysql 数据库
  // mysql:{
  //   enable: true,
  //   package: 'egg-mysql',
  // },
  // sequelize插件，实现数据持久化
  sequelize:{
    enable: true,
     package: 'egg-sequelize',
  },
  // 引入mysql数据库2
  mysql2: {
    enable: true,
    package: 'mysql2',
  },
  // 前后端结合的模板
  nunjucks:{
    enable: true,
    package: 'egg-view-nunjucks',
  },
  // 跨域准备
  cors:{
    enable: true,
    package: "egg-cors",
  },
  // 生成token的插件
   jwt: {
    enable: true,
    package: 'egg-jwt',
  },
  // 实时通讯的插件
  io: {
    enable: true,
    package: 'egg-socket.io'
  },
  redis: {
    enable: false,
    package: 'egg-redis',
  },
  etag: {
    package: 'egg-etag',
  }
};
