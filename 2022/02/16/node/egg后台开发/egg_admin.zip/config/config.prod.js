/* eslint valid-jsdoc: "off" */

'use strict';
const path = require('path');
/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {};


  // cache-control解决这个的缓存时间问题
  config.static = {
    maxAge: 0, // in prod env, 0 in other envs
    buffer: false, // in prod env, false in other envs
  };
  config.etag = {
    weak: false,
  };
  return {
    ...config,
    ...userConfig,
  };
};
