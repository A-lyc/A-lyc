# egg_vue V1
 -- 完成上传，增删改查
 -- 只要服务器没有刷新，定义的数据就不会被刷新
 -- 后端不配置跨域，前端如何跨域 ？？？？
 -- socket = 可以使用，需要单独写文档

 -- 打开需要更改数据库上的信息，
 ```js
 // 自己笔记本电脑
 // host
      host: 'localhost',
      // 端口号
      port: '3307',
      // 用户名
      user: 'exapp_admin',
      // 密码
      password: '123456789',
      // 数据库名
      database: 'exapp_admin',
 ```

# 生成token
  1：按住啊那个egg-jwt ： npm i --save egg-jwt
  2：在plugin.js引入
  ```
  jwt:{
    enable: true,
    package: 'egg-jwt',
  }
  ```
  3:config.default.js配置文件，设置secret，注意secret不能泄露
  config.jwt = {secret:'配置的加密字符串'}
  验证流程’
  1根据用户信息生成一个token 生成之后给到客户端
  2客户端将生成的token保存到浏览器中
  3每次请求的时候请求头携带token
  4服务器一年挣的时候验证token



# Controller:控制器 和Service
Controller ：
自我理解：是一个获取 （servic对数据库操作之后返回的信息） 之后返回给router，数据的控制器

框架提供了一个 Controller 基类，并推荐所有的 Controller 都继承于该基类实现。这个 Controller 基类有下列属性：

ctx - 当前请求的 Context 实例。
app - 应用的 Application 实例。
config - 应用的配置。
service - 应用所有的 service。
logger - 为当前 controller 封装的 logger 对象。
在 Controller 文件中，可以通过两种方式来引用 Controller 基类：
```js
// app/controller/user.js

// 从 egg 上获取（推荐）
const Controller = require('egg').Controller;
class UserController extends Controller {
  // 首页展示
  async index() {
   let {ctx,app} = this
    let data = ctx.request.body // 拿到post请求数据
    let data1 = ctx.params //params  /a/a/a
    let data2 = ctx.request.query //query&
    // 获取数据库
    const result = await ctx.service.// server下的js文件名//js内的方法 // 是个函数（）
    ctx.body =  {result,data,data1,data2}
  }
}
module.exports = UserController;
```
配置路由映射：
```
// app/router.js
module.exports = app => {
  const { router, controller } = app;
  router.get('/', controller.home.index);
};
```

- Service
```js
const Service = require('egg').Service;
class NewsService extends Service {
  /* 这里进行了数据库操作 - 已对接数据库 */
  async list() {
    let { app,ctx } = this;
    // 这个是egg内置的方法
    const res1 = await app.mysql.insert('user', { username: 'egg', phone: '123456789', create_time: '2021-08-16' });
    // 数据库原生的方法
    const res = await app.mysql.query('SELECT * FROM `user` LIMIT 0, 2');
    return res;
  }
}
module.exports = NewsService;

```
每一次用户请求，框架都会实例化对应的 Service 实例，由于它继承于 egg.Service，故拥有下列属性方便我们进行开发：
this.ctx: 当前请求的上下文 Context 对象的实例，通过它我们可以拿到框架封装好的处理当前请求的各种便捷属性和方法。
this.app: 当前应用 Application 对象的实例，通过它我们可以拿到框架提供的全局对象和方法。
this.service：应用定义的 Service，通过它我们可以访问到其他业务层，等价于 this.ctx.service 。
this.config：应用运行时的配置项。
this.logger：logger 对象，上面有四个方法（debug，info，warn，error），分别代表打印四个不同级别的日志，使用方法和效果与 context logger 中介绍的一样，但是通过这个 logger 对象记录的日志，在日志前面会加上打印该日志的文件路径，以便快速定位日志打印位置。


# Middleware 
```js
// 中间件是一个函数
// 使用的时候在router 通过app.middleware.checktoken
function checktoken(){
  // 返回的本身有两个参数
  return async function(ctx,next){
    try{
      console.log('我是中间件的内容')
      // 获取token
      let token = ctx.request.header.token
      // 校验token
      let ddecode = ctx.app.jwt.verify(token, ctx.app.config.jwt.secret)
      //ddecode.name和数据库进项校验也可以
      if (ddecode.name) {
        await next()
      } else {
        ctx.body = '中间件返回用户不存在'
      }
      console.log(ddecode)
    }catch(e){
      ctx.body = '中间件返回用户不存在 - catch'
    } 
  }
}
module.exports = checktoken
```
router使用
```js
// 下面的请求使用了中间件  参数位：路由路径，中间件，控制器返回的内容
  router.get('/jwt', app.middleware.checktoken() ,controller.jwt.index)// jwt 生成token
  router.get('/jwtmessage', app.middleware.checktoken(), controller.jwt.getmessage)
```

# Application
 - 新建app.js  和app文件夹是同级目录
 在app.js中写入方法
 在Controller 文件中使用的时候
 ```js
 console.log(this.app.cache());
```

# req res
可以在 Context 的实例上获取到当前请求的 Request(ctx.request) 和 Response(ctx.response) 实例。
```js
    // app/controller/user.js
    class UserController extends Controller {
      async fetch() {
        const { app, ctx } = this;
        const id = ctx.request.query.id;
        ctx.response.body = app.cache.get(id);
      }
    }
```
Koa 会在 Context 上代理一部分 Request 和 Response 上的方法和属性，参见 Koa.Context。
如上面例子中的 ctx.request.query.id 和 ctx.query.id 是等价的，ctx.response.body= 和 ctx.body= 是等价的。
需要注意的是，获取 POST 的 body 应该使用 ctx.request.body，而不是 ctx.body。

# Helper 暂时理解一个插件
- 定义
// app/extend/helper.js
```js
module.exports = {
  formatUser(user) {
    return only(user, [ 'name', 'phone' ]);
  }
};
```
- 使用
```js
const { app, ctx } = this;
ctx.body = ctx.helper.formatUser(user);
```

# Config 
我们可以通过 app.config 从 Application 实例上获取到 config 对象，也可以在 Controller, Service, Helper 的实例上通过 this.config app.config 获取到 config 对象


## router
```js
  // 下面的请求使用了中间件  参数位：路由路径，中间件，控制器返回的内容
  router.get('/jwt', app.middleware.checktoken() ,controller.jwt.index)// jwt插件 生成token
  router.post('/jwtLogin', controller.jwt.doLogin) // 没使用中间件
```

# 路由
post请求由于egg设置权限所以在config文件夹下的conmfig.js添加
```js
config.security = {
    csrf: {
      enable: false,
    },
  };
```

# 小知识点

let obj = Object.assign({},'拷贝的对象')
```js
const target = { a: 1, b: 2 };
const source = { b: 4, c: 5 };

const returnedTarget = Object.assign(target, source);

console.log(target);
// expected output: Object { a: 1, b: 4, c: 5 }

console.log(returnedTarget);
// expected output: Object { a: 1, b: 4, c: 5 }
```


# 使用egg-sequelize 和 mysql2
1： 首先安装：npm i --save egg-sequelize msyql2
egg-sequelize
  - 1: STRING => varchar(255)
  - 2: INTEGER => int
  - 3: DOUBLE => double
  - 4: DATE => datetime
  - 5: TEXT => text
2： 在plugin.js文件中引入插件
```js
  // sequelize插件，实现数据持久化
  sequelize:{
    enable: true,
     package: 'egg-sequelize',
  },
  // 引入mysql数据库2
  mysql2: {
    enable: true,
    package: 'mysql2',
  },
```
3： 在config.default.js文件中配置这个数据库链接
```js
  // sequelized的配置文件
  config.sequelize = {
    // 数据库类型 是mysql
    dialect:"mysql",
    // host
    host: 'localhost',
    // 端口号
    port: '3307',
    // 用户名
    username: 'exapp_admin',
    // 密码
    password: '123456789',
    // 数据库名
    database: 'exapp_admin',
    // 时区
    timezone:'+08:00'
  }
```
4： 在app/model文件中创建数据模型
5： 添加app.js文件，初始化数据库


在controller中的增删改查
  // 添加
```js
await app.model.Clazz.create({name:name})
// 条件添加
let data = await app.model.Clazz.findAll({ where: { id: id } })
```
  // 删除
```js
await app.model.Clazz.destroy( { where: { id: id } })
```
  // 更新
```js
    await app.model.Clazz.update({ name: name }, { where: { id: id } })
```
// 查看
```js
    let data = await app.model.Clazz.findAll()
    // 按条件查看
    let data = await app.model.Clazz.findAll({where:{id:5}})
```

原则应该在server中实现和数据库之间的交互
```js
 async findAll(){
      let { app } = this
      let data = await app.model.Clazz.findAll()
      return data
  }
```
- 添加外键
在Student通过asssociate属性指定外键
1：创建一个名为clazz的班级表，包含ID，和name两个字段
2：学生模型中添加下面的代码
```js
Student.associate = function(){ // 所属性于那本书，指向书记的主键
  app.model.Student.belongsTo(app.model.clazz,{
    foreignKey:'clazz_id',
    as:'clazz'
  })
}
```


 ###  qrcode生成二维码
 - 简单实现，在服务器端使用生成画布二维码和生成base64的二维码
 - 前端如何实现生成二维码的 需要导入此插件
 - 详细网址：https://www.npmjs.com/package/qrcode