module.exports = app => {
  app.beforeStart(async function(){
    console.log('系统启动的时候执行 会执行这个函数 之后直接创建的数据库的表')
    //  await app.model.sync({force:true})  //每次启动删除全部的表，按照模型创建新的表 开发环境使用，会删除数据表
    // sync方法会根据模型创建一个表
    await app.model.sync({})
  })
  app.cache = () => {
    console.log(app.controller);
    console.log('我是app.js');
    return true;
  };
};
