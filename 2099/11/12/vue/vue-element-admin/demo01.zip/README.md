## 简述

### 框架：
通过应用生成器工具 express-generator 可以快速创建一个应用的骨架。

你可以通过 npx （包含在 Node.js 8.2.0 及更高版本中）命令来运行 Express 应用程序生成器。

```
$ npx express-generator
```
对于较老的 Node 版本，请通过 npm 将 Express 应用程序生成器安装到全局环境中并执行即可。
```js
$ npm install -g express-generator
$ express
```

### 如果一直报错
看我的电脑右键属性 - 服务 - mongoodsever是否启动
(计算机管理内的，如果找不到的话找计算机管理)
或者有占用3000端口的

### express-generator
通过应用生成器工具 express-generator 可以快速创建一个应用的骨架。
```
npm install express-generator -g
```
创建server后台服务文件server
```
express --view=pug server
```
可以看expresss官网:http://www.expressjs.com.cn/starter/generator.html

express后端服务架构，编写后端路由（接口)。不同接口提供不同的服务

安装mongoose
```
npm install mongoose
```

### bin 
node的入口 - 启动的时候是在这个位置启动的

### models
models是一个数据库模型建立，建立mongoose的数据库模型
```js
const mongoose = require('mongoose')
const Schema = mongoose.Schema

// 定义Schema，描述该集合有哪些字段，需要什么类型
const produtSchema = new Schema({
    name:String,
    title:String,
})
// 连接数据库 数据库的表名叫shop 
mongoose.connect('mongodb://localhost/shop', { useNewUrlParser: true })
module.exports = mongoose.model('goods',produtSchema)
```


### pubilc
pubilc公共开放资源文件夹开放css，js，image.....
fileType公共资源开放上传的文件压缩包图片，只有一个目录 - 放置解压文件
upload公共开放资源开放上传的图片有多个文件夹，以日期而定

### routes
路由文件，前端根据路由文件获取数据操作数据库进行文件增删改查，
见news.js
最好每个文件对应一个数据库表或者多个数据库表，在app.js引入
```js
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
app.use('/', indexRouter);
app.use('/users', usersRouter);
```

### uploads
上传文件接受地，所有的图片上传接收在这个位置 - 现在是根据日期上传到所对应的目录
之后自己手动去压缩图片  img.js 执行node img.js 批量压缩已出接口/uploadimg/compress

### fileType
上传的文件可以上传图片

### views
模板文件

### app.js
入口之前文件


### img.js
批量压缩文件到compress这个文件夹内

## unzip.js
打开压缩包方法，不过没什么用 - 返回的时候会缺少一个文件需要待开发一下

## xlsx.js
在线解压xlsx和修改xlsx

## tesseract.js
识别图片上的文字，仅限于英文识别比较好，中文识别比较差 速度比较慢，需要等待


## funcionFile 后期增加处理文件或者别的功能文件夹
 ### pdfLid处理pdf
 - 实现简单的写入文件之后生成pdf具体功能实现需要查看文档去了解。
 - 网址：https://www.npmjs.com/package/pdf-lib，直接在npm包管理上去搜索这个包，即可
 
 ###  qrcode生成二维码
 - 简单实现，在服务器端使用生成画布二维码和生成base64的二维码
 - 前端如何实现生成二维码的 需要导入此插件
 - 详细网址：https://www.npmjs.com/package/qrcode

 ### lyc-ceshi删除两个文件内的名称一样 和名称一样的根目录的空文件夹
 - node file.js执行
 