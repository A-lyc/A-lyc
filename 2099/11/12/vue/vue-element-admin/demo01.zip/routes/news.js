const express = require('express')
const mongoose = require('mongoose')
// 连接数据库 数据库的表名叫table
mongoose.createConnection('mongodb://localhost/news', { useNewUrlParser: true, useUnifiedTopology: true })

// 使用Router
const router = express.Router()

const News = require('../models/news')




//路由获取 列表
router.get('/list', function (req, res, next) {
  //查询mongoDB的goods数据
  News.find().then((doc) => {
    res.json({
      code: 20000,
      data: doc,// 返回数据的名称
      total: doc.length // 返回数据的长度
    })
  }).catch(err => {
    res.json({
      status: '1',
      msg: err.message
    })
  })
});

// 根据ID获取某一个
router.get('/list-id', function (req, res, next) {
  let _id = req.query._id
  //查询mongoDB的goods数据
  News.findOne({ _id: _id }).then((doc) => {
    res.json({
      code: 20000,
      data: doc,// 返回数据的名称
      count: doc.length // 返回数据的长度
    })
  }).catch(err => {
    res.json({
      status: '1',
      msg: err.message
    })
  })
});

// 添加 
router.post('/add', function (req, res, next) {
  let body = req.body
  //查询mongoDB的goods数据
  let obj = new News(body)
  obj.save().then(doc => {
    console.log(doc)
    res.json({
      code: 20000,
      message: '提交成功',
      data: doc,// 返回数据的名称
      count: doc.length // 返回数据的长度
    })
  }).catch(rej => {
    res.json({
      code: 40000,
      message: '删除失败，请检查网络问题',
      data: data,// 返回数据的名称
    })
  })
});

// 删除
router.delete('/del', (req, res, next) => {
  let _id = req.body._id
  News.remove({ _id }).then(data => {
    res.json({
      code: 20000,
      message: '删除成功',
      data: data,// 返回数据的名称
    })
  }).catch(rej => {
    res.json({
      code: 40000,
      message: '删除失败，请检查网络问题',
      data: data,// 返回数据的名称
    })
  })
})

// 修改
router.post('/amend', (req, res) => {
  let _id = req.query._id
  
  let body = req.body
  console.log(_id)
  console.log(body)
  News.findByIdAndUpdate(_id, body).then(data => {
    res.json({
      code: 20000,
      message: '修改成功',
      data: data,// 返回数据的名称
    })
  })
})


module.exports = router; //暴露路由
