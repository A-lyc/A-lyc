const mongoose = require('mongoose')
const Schema = mongoose.Schema

// 需要建立有个详情的表
// 定义Schema，描述该集合有哪些字段，需要什么类型
const produtSchema = new Schema({
  title: {
    type: String,
    required: true
  }, // 标题
  author:{
    type:String,
    default:'四叶草'
  },
  img: {
    type:Array,
    default: undefined
  }, // 图片
  described: String, // 摘要
  status:{
    type:String,
    default:'success'
  },// 成功与否 标签，表示
  display_time: {
    type: Date,
    default: Date.now
  },// 时间： 前端裁切字符串进行显示
  type:{
    type:Array,
    default:undefined
  }, // 保留分类，类型的
  content:String,// 内容 - 富文本的内容
})

// //下面就进行判断，（连接成功，连接失败，连接断开）
// mongoose.connection.on('connected', function () {
//   console.log("连接成功 - 04");
// })
// mongoose.connection.on('error', function () {
//   console.log("连接失败 - 05");
// })
// mongoose.connection.on('disconnected', function () {
//   console.log("断开连接 - 06");
// })
// mongoose.connection.on('open', function () {
//   console.log("连接ok");
// })

module.exports = mongoose.model('list', produtSchema)

