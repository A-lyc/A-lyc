const fs = require('fs')

const path = require("path");
// await fs.unlink(path);
// console.log(`已成功地删除文件 ${path}`);


/**
 * 获取文件的内的文件 只获取一层
 * 
*/
async function print(path) {
  let newFiles = []
  const dir = await fs.promises.opendir(path);
  for await (const dirent of dir) {
    newFiles.push(dirent.name)
  }
  return newFiles
}

// 返回两个文件的根目录的列表
async function filesList(path,oldpath) {
  let filseList = await print('./1')
  let oldfilseList = await print('./2')
  return {
    oldfilseList,
    filseList
  }
}


// 及逆行删除
async function unlinkFile(params) {
  let { filseList, oldfilseList } = await filesList()
  for await (let i of filseList) {

  oldfilseList.forEach(item => {
    
    fs.access('./1/' + item,err =>{
      return
    })

    if (item == i) {
      try {
       let index =  item.indexOf('.')
       // true index == -1 是不带后缀的文件夹 删除空文件夹
        if (index == -1){
          fs.rmdir('./1/' + item,(err) =>{ 
            console.log(err)
          if (err) throw err;
           console.log('删除成功' + err)
         })
       }else{
          fs.unlink('./1/' + item, (err) => {
          console.log(err)
          console.log('文件已被删除');
        });
       }
      } catch (err) {
        console.log(err)
      }
    } else {
      console.log('item != i')
    }
  })
}
}

unlinkFile()





