var QRCode = require('qrcode')
var toSJIS = require('qrcode/helper/to-sjis')
var segs = [
  { data: 'ABCDEFG', mode: 'alphanumeric' },
  { data: '0123456', mode: 'numeric' }
]
console.log(toSJIS)
// 服务器端使用·
QRCode.toString(segs, { type: 'terminal' }, function (err, url) {
  console.log(url) // 生成的事张canvas的图
})
// 服务器端，base64格式的图片
QRCode.toDataURL(segs, { errorCorrectionLevel: 'H' }, function (err, url) {
  console.log(url)// base64图片
})

QRCode.toDataURL('kanjiString', { toSJISFunc: toSJIS }, function (err, url) {
  console.log(url)// base64图片
})

/**
 * 在vue中时使用
 * 
 */
// let canvas = this.$refs['canvas']
// QRCode.toCanvas(canvas, 'sample text', { errorCorrectionLevel: 'H' }, function (error, url) {
//   if (error) console.error(error)
//   console.log('success!')
//   console.log(url)
// })