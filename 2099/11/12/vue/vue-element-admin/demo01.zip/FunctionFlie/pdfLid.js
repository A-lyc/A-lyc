const { PDFDocument, StandardFonts, rgb } = require('pdf-lib')
const fs = require('fs')

async function PdfLib(params) {
  // 创建一个新的PDF文档
  const pdfDoc = await PDFDocument.create()

  // // 嵌入Times Roman字体 需要导入StandardFonts
  const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman)

  // 向文档中添加一个空白页
  const page = pdfDoc.addPage()
  // 获取页面的宽度和高度
  const { width, height } = page.getSize()
  // 在页面顶部绘制一串文本 写入的内容
  const fontSize = 30
  page.drawText('Creating PDFs in JavaScript is awesome!', {
    x: 10,// x轴线的距离从底部计算
    y: 1,// y轴线的距离从底部计算
    size: fontSize,// 大小
    font: timesRomanFont,//字体
    color: rgb(0, 0.53, 0.71),//字体颜色
  })
  // 将PDFDocument序列化为字节(一个Uint8Array)
  const pdfBytes = await pdfDoc.save()


  console.log(pdfBytes)

  fs.writeFile('./out.pdf', pdfBytes,error => {
    if(error)return console.log('失败')
    console.log('成功')
  })
// For example, `pdfBytes` can be:
//   • Written to a file in Node
//   • Downloaded from the browser
//   • Rendered in an <iframe>
}

PdfLib()