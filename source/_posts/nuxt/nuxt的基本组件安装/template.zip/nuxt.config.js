export default {
  // Global page headers (https://go.nuxtjs.dev/config-head)
  head: {
    title: '标题',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: '' }
    ],
    link: [//使用到的css可以使用link标签引入
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
    ]
  },

  // Global CSS (https://go.nuxtjs.dev/config-css)
  css: [
    'element-ui/lib/theme-chalk/index.css'
  ],

  // Plugins to run before rendering page (https://go.nuxtjs.dev/config-plugins)
  plugins: [
    '@/plugins/element-ui',
    '@/plugins/cookies',// 获取token
    '@/plugins/api'//封装的axios
  ],

  // Auto import components (https://go.nuxtjs.dev/config-components)
  components: true,

  // Modules for dev and build (recommended) (https://go.nuxtjs.dev/config-modules)
  buildModules: [
  ],

  // Modules (https://go.nuxtjs.dev/config-modules)
  modules: [
    // https://go.nuxtjs.dev/axios
    '@nuxtjs/axios',
    '@nuxtjs/proxy'
  ],
  axios: {
    prefix: '/api/',
    //是否允许跨域
    proxy: true,
    // 最多重发5次
    retry: { retries: 5 },
    //开发模式下开启debug - 正式上线记住关闭
    debug: process.env._ENV == 'production' ? false : true,
    // 设置不同环境的请求地址
    baseURL:
      process.env._ENV == 'production'
        ? 'http://localhost:3000/api'
        : 'http://localhost:3000/api',
    //是否是可信任
    withCredentials: true
  },
//切换网页url不正确 - 具体是意思不明
  publicRuntimeConfig: {
    axios: {
      browserBaseURL: process.env.BROWSER_BASE_URL
    }
  },
//切换网页url不正确 - 具体是意思不明
  privateRuntimeConfig: {
    axios: {
      baseURL: process.env.BASE_URL
    }
  },
  // 代理服务器
  proxy: {
    '/api/': {
      target: 'https://www.XXXXXX.com/api',  // 线上地址
      pathRewrite: { '^/api/': '' }
    }
  },
  // Build Configuration (https://go.nuxtjs.dev/config-build)
  build: {
    transpile: [/^element-ui/],
  },
  middleware: [
    'router'
  ]
}
