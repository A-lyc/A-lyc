<template>
  <h1 class="title">
    zhixueV3
  </h1>
</template>

<script>
    export default {
      name: "home",
      asyncData(content){
          console.log('*/*/*/*/*/*/*')
      }
    }
</script>

<style scoped>

</style>
