<template>
  <div class="container">
    <div>
      <router-link to="/home">
      <Logo/>
      </router-link>
      <h1 class="title">
        zhixueV3
      </h1>
      <div class="links">
        <a
          class="button--green"
          href="https://nuxtjs.org/"
          rel="noopener noreferrer"
          target="_blank"
        >
          Documentation
        </a>
        <a
          class="button--grey"
          href="https://github.com/nuxt/nuxt.js"
          rel="noopener noreferrer"
          target="_blank"
        >
          GitHub
        </a>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'index',
    asyncData({app}) {
      let {$app,$cookies} = app
      console.log('--- 1 ---')
      console.log($app)
      console.log($cookies)
    },
    created() {
      this.$api.getListData().then(res => {
        console.log('--- 5 ---')
        console.log(res)
      }).catch(e => {
        console.log(e)
      })
      console.log(this.$api)
      this.$cookies.setToken('abcdefghigklmnopqistuvwsyz')
      setTimeout(() => {
        console.log(this.$cookies.getToken())
      }, 1000)

    }
  }
</script>

<style>
  .container {
    margin: 0 auto;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
  }

  .title {
    font-family: 'Quicksand',
    'Source Sans Pro',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    'Helvetica Neue',
    Arial,
    sans-serif;
    display: block;
    font-weight: 300;
    font-size: 100px;
    color: #35495e;
    letter-spacing: 1px;
  }

  .subtitle {
    font-weight: 300;
    font-size: 42px;
    color: #526488;
    word-spacing: 5px;
    padding-bottom: 15px;
  }

  .links {
    padding-top: 15px;
  }
</style>
