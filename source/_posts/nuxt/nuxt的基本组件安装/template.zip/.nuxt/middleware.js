const middleware = {}

middleware['cookies'] = require('..\\middleware\\cookies.js')
middleware['cookies'] = middleware['cookies'].default || middleware['cookies']

middleware['router'] = require('..\\middleware\\router.js')
middleware['router'] = middleware['router'].default || middleware['router']

export default middleware
