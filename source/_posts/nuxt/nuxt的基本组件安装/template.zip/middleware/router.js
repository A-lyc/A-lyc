
export default function (content) {
  console.log('-**--*-*-*-*-*-*-*-*')
  console.log('-**--*-*- 中间件内容 *-*-*-*-*-*')
}
