import Cookies from 'js-cookie'

const TokenKey = 'token'

// 获取
function getToken() {
  return Cookies.get(TokenKey)
}

// 写入
function setToken(token) {
  return Cookies.set(TokenKey, token,{ expires: 7 })
}

// 删除
function removeToken() {
  return Cookies.remove(TokenKey)
}

export default function(content,inject) {
  let cookies ={
    getToken,
    setToken,
    removeToken
  }
  inject('cookies',cookies)
}
