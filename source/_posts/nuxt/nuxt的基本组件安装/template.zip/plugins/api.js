import apiAll from '../api/index.js'//导入请求的n个地址 地址自定义
export default function ({ app }, inject) {

  let { store, $axios, $cookies } = app//结构出store, $axios - 自带的axios
  // $axios.defaults.baseUrl = '/api/'// 设置api，nuxt.confige.js中以解释/api的来历
  /** 拦截请求设置 可以做一些请求之前的操作 token **/
  $axios.interceptors.request.use(
    function (config) {
      let Token = ''
      if (process.browser) {
        Token = window.localStorage.getItem('token')
      }

      config.headers['Authorization'] = 'Bearer ' + Token
      // 在发送请求之前做些什么
      console.log('---- $cookies ----')
      console.log($cookies.getToken())
      return config
    },
    function (error) {
      // 对请求错误做些什么
      return Promise.reject(error)
    }
  )
// 2.2.响应拦截
  $axios.interceptors.response.use(res => {
//获取的数据返回一个data
    return res.data
  }, err => {
    return err.data
  })
  //inject全局暴漏，名字为api 导出的是这个axios
  inject('api', apiAll($axios))
}
