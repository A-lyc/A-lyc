export default function ($axios) {
  return {
    /**
     * 获取数据
     * */
    getListData () {
      console.log('--- 获取数据 ---')
      return $axios.get('/v1/index')
    },
    /**
     *  热门分类 /v1/index/hot-type
     * */
    getHotType(id,data) {
      return  $axios.post("/v1/index/hot-type?id=" + id,{
        name:data.name
      })
    },
    /**
     * 传输图片，fil格式，前提提前转froomData格式
     * */
    uImage(data) {
      return $axios.post('/v1/file/images',data)
    }
  }
}
