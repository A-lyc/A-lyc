// 导入压缩包
const StreamZip = require('node-stream-zip');

// 导入文件模块
const fs = require('fs');

// 插件字写 格式化时间
const { getNowFormatDate } = require('./common/dateTime')
let time = getNowFormatDate('')

// 手动删除压缩包
  // 文件路径，固定的
  let filesType = './fileType/'

  // 查找 某个文件
  const zip = new StreamZip({
    file: './fileType/files-1605681955440.zip',
    storeEntries: true
  });

  // 错误的时候
  zip.on('error', err => {
    console.log(err)
  });

  // 读取条目
  zip.on('entry', function (entry) {
    // 读取条目描述后，在加载时调用
    // 您已经可以对该条目进行流处理，而无需等到所有条目描述都已读取(适合非常大的归档)
    console.log('读条目 ', entry.name);
  });

  // 输入序列
  // zip.on('ready', () => {
  //   console.log('Entries read: ' + zip.entriesCount);
  //   for (const entry of Object.values(zip.entries())) {
  //     const desc = entry.isDirectory ? 'directory' : `${entry.size} bytes`;
  //     console.log(`读条目 - 读条目 - ${entry.name}: ${desc}`);
  //   }
  //   zip.close()
  // });

  // 将一个文件解压缩到磁盘
  // zip.on('ready', () => {
  //   zip.extract('./fileType/files-1605681955440.zip', './fileType/', err => {
  //     console.log(err ? 'Extract error' : 'Extracted');
  //     zip.close();
  //   });
  // });

  // 将文件夹从归档文件解压缩到磁盘
  // zip.on('ready', () => {
  // 创建目录
  //   // fs.mkdirSync('extracted');
  //   zip.extract('./fileType/files-1605681955440.zip', './fileType/', err => {
  //     console.log(err ? 'Extract error' : 'Extracted+++++');
  //     zip.close();
  //   });
  // });

  // 提取所有
  zip.on('ready', () => {
    // 创建目录
    // fs.mkdirSync('extracted');
    // 1：unll ，2：文件路径， 3：回调函数
    zip.extract(null, './fileType', (err, count) => {
      console.log(err ? 'Extract error' : `Extracted ${count} entries`);
      zip.close();
    });
  });

  // 以同步方式读取作为缓冲区的文件
  // zip.on('ready', () => {
  //   const data = zip.entryDataSync('./fileType/files-1605681955440.zip');
  //   console.log('以同步方式读取作为缓冲区的文件')
  //   console.log(data)
  //   zip.close();
  // });

  // 在解压文件夹时，您可以侦听解压事件 - 图片重命名
  zip.on('extract', (entry, file) => {
    console.log('在解压文件夹时，您可以侦听解压事件')
    console.log(`Extracted ${entry.name} to ${file}`);
    let name = file.split('.')[1]
    /**
     * 1：旧文件所在的目录，包括文件名，2：新文件所在的目录，包括文件名，3：回调
     */
    fs.rename(`${file}`, `./fileType/files-${Date.now()}${time}.${name}`, err => {
      if (err) throw err;
      console.log('重命名完成')
      // 写入数据库信息
    })
  });

  // 在加载期间为每个条目生成条目事件
  zip.on('entry', entry => {
    console.log('在加载期间为每个条目生成条目事件')
    // you can already stream this entry,
    // without waiting until all entry descriptions are read (suitable for very large archives)
    console.log(`XXX ：  ${entry.name}`);
  });



