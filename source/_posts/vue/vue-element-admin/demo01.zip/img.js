const images = require("images");
const fs = require("fs");
// 导入路径
const WithPath = require('path')

const path = "uploads"; // 需要传入一个参数是文件目录
const outpath = "compress"; // 压缩后的文件夹，是否保存源文件的问题
module.exports = function compress(path) {
  fs.readdir(path, function (err, files) {
    if (err) {
      console.log('error:\n' + err);
      return;
    }
    files.forEach(function (file) {
      fs.stat(WithPath.join(__dirname, path + '/' + file), function (err, stat) {
        if (err) { console.log(err); return; }
        if (stat.isDirectory()) {
          // 如果是文件夹遍历
          compress(path + '/' + file);
        } else {
          //遍历图片
          // console.log(__dirname + '文件名:' + path + '/' + file);
          // console.log(WithPath.join(__dirname, path + '/' + file))
          var name = path + '/' + file;
          var outName = outpath + '/' + file
          images(name).size(1200).save(name, {
            quality: 82                    //保存图片到文件,图片质量为50
          });
        }
      });

    });

  });
}

