var express = require('express');
const user = require('../models/user')
var router = express.Router();
const mongoose = require('mongoose')
// 创建数据库表
mongoose.createConnection('mongodb://localhost/userInfo', { autoIndex: false })



/* GET users listing. */
router.post('/create-user', (req, res) => {
  let body = req.body
  let admin = new user({ username: body.username, password: body.password })
  admin.save().then(doc=>{
    res.json({
      code: 20000,
      data: doc
    })
  }).catch(error => {
    res.json({
      code: 40000,
      data: error,
      message: '创建失败'
    })
  })

});

/* GET users listing. */
router.post('/login', (req, res) => {
  let body = req.body
  user.findOne({ username: body.username, password: body.password}).then(doc=>{
      res.json({
        code: 20000,
        data:doc
      })
    }).catch(error => {
      res.json({
        code: 40000,
        data: error,
        message: '账号密码错误，请重新输入'
      })
    })
    
});
router.get('/info',(req,res)=>{
  let query = req.query
  user.findOne({ token: query.token }).then(doc => {
    res.json({
      code: 20000,
      data: doc
    })
  }).catch(error => {
    res.json({
      code: 40000,
      data: error,
      message: '账户失效，或者不对'
    })
  })
})

module.exports = router;



