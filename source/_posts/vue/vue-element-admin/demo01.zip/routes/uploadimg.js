

const express = require('express')

// 导入文件系统
const fs = require('fs')

// 导入路径
const path = require('path')


// 使用Router
const router = express.Router()

const upload = require('../models/uploadimg')



router.post('/', upload.single('files'), async (req, res) => {
  try {
    let file = req.file
    // 返回的线上地址
    file.url = `http://localhost:3000/uploads/${file.filename}`
    // 返回json数据
    res.json({
      code: 20000,
      data: file,// 返回数据的名称
    })
  } catch (e) {
    console.log(e)
  }
})


router.delete('/', async (req, res) => {
  try {
    let body = req.body
    let name = body.filename
    fs.unlinkSync(path.join(__dirname, '../uploads/' + name))
    res.json({
      code: 20000,
      data: [],// 返回数据的名称
      message: '文件已删除',// 返回数据的名称
    })
    
  } catch (e) {
    console.log('错误')
    console.log(e)
  }
})

module.exports = router;
