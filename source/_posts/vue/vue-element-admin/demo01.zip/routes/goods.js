const express = require('express')

// 导入可接收图片的插件
var multer = require('multer')

// 使用Router
const router = express.Router()

// 定义图片中间件的内容
var storage = multer.diskStorage({
    // 定义保存图片的地址
    destination: function (req, file, cb) {
        cb(null, __dirname + '/../uploads')
    },
    // 定义保存图片的名称，默认没有后缀名，需要添加后缀名
    filename: function (req, file, cb) {
        let mimetype = file.mimetype.split('/')[1]
        cb(null, file.fieldname + '-' + Date.now() + '.' + mimetype)
    }
})
// 使用图片中间见
var upload = multer({ storage })

const Goods = require('../models/goods')



//路由获取 列表
router.get('/', function (req, res, next) {
    //查询mongoDB的goods数据
    Goods.find().then((doc) =>{
        res.json({
            data:doc,// 返回数据的名称
            count:doc.length // 返回数据的长度
        })
    }).catch(err=>{
        res.json({
            status: '1',
            msg: err.message
        })
    })
});

// 添加
router.get('/add', function (req, res, next) {
    //查询mongoDB的goods数据
    let obj = new Goods({
        name:'四叶草',
        title:'这是内容信息'
    })
    obj.save().then(doc =>{
        res.json({
            data:doc,// 返回数据的名称
            count:doc.length // 返回数据的长度
        })
    })
});

// 删除
router.get('/del',(req, res, next) => {
    let id = req.query.id
    Goods.remove({_id: id}).then(data=>{
        res.json({
            data:data,// 返回数据的名称
        })
    })


})

// 修改
router.post('/amend',(req,res)=>{
    let data = req.body
    Goods.findByIdAndUpdate(data.id,{
        name: data.name,
    }).then(data => {
        res.json({
            data: data,// 返回数据的名称
        })
    })
})

// 上传upload.single('files') files上传文件类型
router.post('/upImage',upload.single('files'),async (req,res)=>{
    try{
        // 接收传来的信息 
        let file = req.file
        // 传来之后返回数据 定义返回数据的 url，方便线上访问
        file.url = `http://localhost:3000/uploads/${file.filename}`
        res.json({
            data: file,// 返回数据的名称
        })
    }catch(e){
        console.log(e)
    }
})

module.exports = router; //暴露路由






