const express = require('express')
const mongoose = require('mongoose')

// 使用Router
const router = express.Router()

// 导入文件系统
const fs = require('fs')

// 导入路径
const path = require('path')

// 上传文件-图片
const multer = require('multer')


// 定义图片中间件的内容
const storage = multer.diskStorage({
  // 定义保存图片的地址
  destination: function (req, file, cb) {
    let path = __dirname + '/../fileType/'
    cb(null, path)
  },
  // 定义保存图片的名称，默认没有后缀名，需要添加后缀名
  filename: function (req, file, cb) {
    let suffix = file.originalname.split('.')
    suffix = suffix[suffix.length - 1]
    cb(null, file.fieldname + '-' + Date.now() + '.' + suffix)
  }
})

const upload = multer({ storage })

// 连接数据库 数据库的表名叫uploadfile
mongoose.connect('mongodb://localhost/uploadfile', { useNewUrlParser: true })

// 操作数据库
let UploadFile = require('../models/uploadFile')

// 上传
router.post('/', upload.single('files'), async (req,res) => {
  try {
    let file = req.file
    console.log(file)
    file.url = `http://localhost:3000/fileType/${file.filename}`
    let obj = new UploadFile(file)
    obj.save().then(doc => {
      console.log(doc)
      res.json({
        code: 20000,
        message: '提交成功',
        data: doc,// 返回数据的名称
        count: doc.length // 返回数据的长度
      })
    }).catch(rej => {
      res.json({
        code: 40000,
        message: '删除失败，请检查网络问题',
        data: data,// 返回数据的名称
      })
    })
  } catch (e) {
    console.log(e)
  }
})

// 获取数据
router.get('/',async (req,res) => {
  UploadFile.find().then(doc =>{
    res.json({
      code: 20000,
      data: doc,// 返回数据的名称
      count: doc.length // 返回数据的长度
    })
  }).catch(err => {
    res.json({
      status: '1',
      msg: err.message
    })
  })
})

// 删除数据
router.delete('/del', async (req, res) => {
  try{
    let body = req.body
    console.log(body)
  UploadFile.remove({_id:body._id}).then(data => {
    fs.unlinkSync(body.path);
    console.log('已成功删除文件');
    res.json({
      code: 20000,
      message: '删除成功',
      data: data,// 返回数据的名称
    }).catch(rej => {
      res.json({
        code: 40000,
        message: '删除失败，请检查网络问题',
        data: data,// 返回数据的名称
      })
    })
  })
  }catch{
    console.log('错误')
  }
})

router.post('/upload',async (req,res)=> {
  let body = req.body
  if(fs.existsSync(body.path)){
    console.log('路径已存在' + body.path)
  } 

})


module.exports = router;