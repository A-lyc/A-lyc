/**
 * 导入Excel
 * 
 * 
 */
const xlsx = require('node-xlsx')
const fs = require('fs');

// 解析得到文档中的所有 sheet
let sheets = xlsx.parse('./fileType/123456789.xlsx');

// 遍历 sheet
sheets.forEach(function (sheet) {
  console.log(sheet['name']);
  // 读取每行内容
  for (let rowId in sheet['data']) {
    console.log(rowId);
    let row = sheet['data'][rowId];
    console.log(row);
  }
});

var data = [
  {
    name: 'sheet1',
    data: [
      [
        'ID',
        'Name',
        'Score'
      ],
      [
        '1',
        'Michael',
        '99'

      ],
      [
        '2',
        'Jordan',
        '98'
      ]
    ]
  },
  {
    name: 'sheet2',
    data: [
      [
        'AA',
        'BB'
      ],
      [
        '23',
        '24'
      ]
    ]
  }
]
var buffer = xlsx.build(data);

// 写入文件
fs.writeFile('a.xlsx', buffer, function (err) {
  if (err) {
    console.log("Write failed: " + err);
    return;
  }
  console.log("Write completed.");
});