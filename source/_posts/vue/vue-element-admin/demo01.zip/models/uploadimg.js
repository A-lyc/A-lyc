// 导入可接收图片的插件
const multer = require('multer')
// 定义图片中间件的内容
const storage = multer.diskStorage({
  // 定义保存图片的地址
  destination: function (req, file, cb) {
    cb(null, __dirname + '/../uploads')
  },
  // 定义保存图片的名称，默认没有后缀名，需要添加后缀名
  filename: function (req, file, cb) {
    let mimetype = file.mimetype.split('/')[1]
    cb(null, file.fieldname + '-' + Date.now() + '.' + mimetype)
  }
})
module.exports = multer({ storage })