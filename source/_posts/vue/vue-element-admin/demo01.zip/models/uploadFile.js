const mongoose = require('mongoose')
const Schema = mongoose.Schema

// 定义Schema，描述该集合有哪些字段，需要什么类型
const produtSchema = new Schema({
  fieldname: String,
  originalname: String,
  mimetype:String,
  destination: String,
  path: String,// *
  size: String,
  url:String // *
})

module.exports = mongoose.model('file', produtSchema)