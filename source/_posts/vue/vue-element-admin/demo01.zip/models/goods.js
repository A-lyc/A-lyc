const mongoose = require('mongoose')
const Schema = mongoose.Schema

// 定义Schema，描述该集合有哪些字段，需要什么类型
const produtSchema = new Schema({
    name:String,
    title:String,
})
// 连接数据库 数据库的表名叫shop 
mongoose.connect('mongodb://localhost/shop', { useNewUrlParser: true })
module.exports = mongoose.model('goods',produtSchema)

