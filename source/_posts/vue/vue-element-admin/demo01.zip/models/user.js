const mongoose = require('mongoose')
const Schema = mongoose.Schema
// // 创建数据库表
// mongoose.createConnection('mongodb://localhost/userInfo', { autoIndex: false })

// 定义Schema，描述该集合有哪些字段，需要什么类型
const produtSchema = new Schema({
  adminId:{
    type:String
  },
  roles: {
    type:Array,
    required:true,
    default(){
      return []
    }
  },// 权限
  introduction: {
    type:String,
    default: 'I am a super administrator'
  }, // 介绍
  avatar:{
    type:String,
    default: 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif'
  } , //头像
  username: String,//用户名
  password: String,//密码
  name:{
    type:String,
    default:'admin-四叶草'
  },
  token: {
    type: String,
    default: 'a4c45ric80hkca6du6hkk0ii7k'
  },
})



//下面就进行判断，（连接成功，连接失败，连接断开）
mongoose.connection.on('connected', function () {
  console.log("连接成功 - 01");
})
mongoose.connection.on('error', function () {
  console.log("连接失败 - 02");
})
mongoose.connection.on('disconnected', function () {
  console.log("断开连接 - 03");
})
mongoose.connection.on('open', function () {
  console.log("连接ok");
})
module.exports = mongoose.model('user', produtSchema)

