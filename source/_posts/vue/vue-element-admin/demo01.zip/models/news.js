const mongoose = require('mongoose')
const Schema = mongoose.Schema

// 需要建立有个详情的表
// 定义Schema，描述该集合有哪些字段，需要什么类型
const produtSchema = new Schema({
  title: {
    type: String,
    required: true
  }, // 标题
  author: {
    type: String,
    default: '四叶草'
  },
  image_uri: {
    type: String,
    default: ''
  }, // 图片
  content_short: String, // 摘要
  importance: {
    type: Number,
    default: 0
  },// 成功与否 标签，表示
  display_time: {
    type: Date,
    default: Date.now
  },// 时间： 前端裁切字符串进行显示
  content: String,// 内容 - 富文本的内容
})

module.exports = mongoose.model('news', produtSchema)

