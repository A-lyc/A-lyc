<template>
  <div class="app-container">
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
      <el-table-column align="center" label="ID" width="95">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="标题" width="300">
        <template slot-scope="scope">
          {{ scope.row.title }}
        </template>
      </el-table-column>
      <el-table-column label="作者" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.author }}</span>
        </template>
      </el-table-column>
      <el-table-column label="描述"  align="center">
        <template slot-scope="scope">
          {{ scope.row.described }}
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="时间" width="200">
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span> {{ scope.row.display_time.substr(0,10) }}</span>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="150">
        <template slot-scope="scope">
          <el-button type="text" size="small">查看</el-button>
          <el-button @click="editClick(scope.row,scope.$index)" type="text" size="small">编辑</el-button>
          <el-button @click="deleteClick(scope.row,scope.$index)" type="text" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getList, setDelete } from '@/api/table'

export default {
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      list: null,
      listLoading: true
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    // 获取数据列表
    fetchData() {
      this.listLoading = true
      getList().then(response => {
        console.log('---- table.vue ---- ')
        this.list = response.data
        this.listLoading = false
      })
    },
    // 删除某条数据
    deleteClick(row, index) {
      console.log('删除某条数据')
      console.log(index)
      this.$confirm('重置表单内容......', '重置', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        setDelete({ _id: row._id }).then(res => {
          this.list.splice(index, 1)
          this.$message({
            type: 'success',
            message: res.message
          })
        })
      }).catch((rej) => {
        this.$message({
          type: 'info',
          message: rej.message
        })
      })
    },
    // 编辑
    editClick(row, index) {
      console.log(this.$router)
      this.$router.push({ path: '/example/edit?_id=' + row._id })
    }
  }
}
</script>
