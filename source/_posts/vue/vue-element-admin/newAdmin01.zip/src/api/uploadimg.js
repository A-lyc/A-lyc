import request from '@/utils/request'

// 上传 图片
export function getUpImage(data) {
  return request({
    url: '/uploadimg',
    method: 'post',
    data
  })
}

// 删除 图片
export function getDeleteImage(data) {
  return request({
    url: '/uploadimg',
    method: 'delete',
    data
  })
}
