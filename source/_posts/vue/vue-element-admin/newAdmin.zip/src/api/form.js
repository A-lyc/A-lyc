import request from '@/utils/request'

// from 添加新闻
export function setAdd(data) {
  return request({
    url: '/table/add',
    method: 'post',
    data
  })
}

// from 编辑新闻
export function getAmend(_id, data) {
  return request({
    url: '/table/amend?_id=' + _id,
    method: 'post',
    data
  })
}

// from 获取某一条数据
export function getListId(_id) {
  return request({
    url: '/table/list-id?_id=' + _id,
    method: 'get'
  })
}
