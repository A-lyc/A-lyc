import request from '@/utils/request'
// 添加数据
export function getAdd(data) {
  return request({
    url: '/news/add',
    method: 'post',
    data
  })
}

// 获取数据
export function getNewslist(data) {
  return request({
    url: '/news/list',
    method: 'get'
  })
}

// 获取单个数据
export function getNewsOne(_id) {
  return request({
    url: '/news/list-id?_id=' + _id,
    method: 'get'
  })
}

// 获取单个数据
export function getNewsAmend(_id, data) {
  return request({
    url: '/news/amend?_id=' + _id,
    method: 'post',
    data
  })
}
