import request from '@/utils/request'

// 传输账号密码，获取token
export function login(data) {
  return request({
    url: '/users/login',
    method: 'post',
    data
  })
}

// 根据token获取用户信息
export function getInfo(token) {
  return request({
    url: '/users/info?token=' + token,
    method: 'get'
  })
}

export function logout() {
  return request({
    url: '/vue-admin-template/user/logout',
    method: 'post'
  })
}

export function news() {
  return request({
    url: '/news',
    method: 'get'
  })
}
