import request from '@/utils/request'

// 上传
export function getUpFile(data) {
  return request({
    url: '/uploadFile',
    method: 'post',
    data
  })
}

// 删除
export function getDeleteFile(data) {
  return request({
    url: '/uploadFile/del',
    method: 'delete',
    data
  })
}
// 上传
export function getUpFileList(data) {
  return request({
    url: '/uploadFile',
    method: 'get',
    data
  })
}
// 解压缩
export function getUpFileUpload(data) {
  return request({
    url: '/uploadFile/upload',
    method: 'post',
    data
  })
}
