<template>
  <div class="upload-container">
    <el-button :style="{background:color,borderColor:color}" @click=" dialogVisible=true" icon="el-icon-upload"
               size="mini"
               type="primary">
      上传图片
    </el-button>
    <el-dialog :visible.sync="dialogVisible">
      <el-upload
        :before-upload="beforeUpload"
        :file-list="fileList"
        :multiple="true"
        :on-remove="handleRemove"
        :on-success="handleSuccess"
        :show-file-list="true"
        action="#"
        class="editor-slide-upload"
        list-type="picture-card"
      >
        <el-button size="small" type="primary">
          点击上传
        </el-button>
      </el-upload>
      <el-button @click="dialogVisible = false">
        取消
      </el-button>
      <el-button @click="handleSubmit" type="primary">
        上传
      </el-button>
    </el-dialog>
  </div>
</template>

<script>
  import { getUpImage, getDeleteImage } from '@/api/uploadimg'

  export default {
    name: 'EditorSlideUpload',
    props: {
      color: {
        type: String,
        default: '#1890ff'
      }
    },
    data() {
      return {
        dialogVisible: false,
        listObj: {},
        fileList: []
      }
    },
    methods: {
      // checkAllSuccess() {
      //   return Object.keys(this.listObj).every(item => this.listObj[item].hasSuccess)
      // },
      handleSubmit() {
        // if (!this.checkAllSuccess()) {
        //   this.$message('Please wait for all images to be uploaded successfully. If there is a network problem, please refresh the page and upload again!')
        //   return
        // }
        this.$emit('successCBK', this.fileList)
        this.listObj = {}
        this.fileList = []
        this.dialogVisible = false
      },
      handleSuccess(response, file) {
        console.log('上传成功的钩子')
        console.log(response)
        console.log(file)
      },
      handleRemove(file) {
        console.log('删除的钩子')
        if(file.status=="ready") {
          return
        }
        getDeleteImage(file).then(res => {
          console.log('网络请求删除的钩子')
          let index = this.fileList.findIndex(item => {
            return item.filename == file.filename
          })
          this.fileList.splice(index, 1)
          this.$message({
            type: 'success',
            message: res.message
          })
        })
      },
      beforeUpload(file) {
        console.log('上传以前钩子')
        let param = new FormData()
        param.append('files', file)
        getUpImage(param).then(res => {
          let img = {
            url: res.data.url,
            name: res.data.originalname,
            filename: res.data.filename,
            uid: file.uid
          }
          this.fileList.push(img)
        })
        return true
      }
    }
  }
</script>

<style lang="scss" scoped>
  .editor-slide-upload {
    margin-bottom: 20px;

    ::v-deep .el-upload--picture-card {
      width: 100%;
    }
  }
</style>
