<template>
  <div class="app-container">
    <el-form :model="form" label-width="120px" ref="form">
      <el-form-item label="文件">
        <el-upload
          action="#"
          :before-upload="beforeUpload"
          list-type="picture-card"
          :file-list="fileList">
          <i class="el-icon-plus" slot="default"></i>
          <div slot="file" slot-scope="{file}">
            <img :src="file.url" alt="" class="el-upload-list__item-thumbnail">
            <span class="el-upload-list__item-actions">
              <span @click="handlePictureCardPreview(file)" class="el-upload-list__item-preview">
                <i class="el-icon-zoom-in"></i>
              </span>
              <span @click="handleDownload(file)" class="el-upload-list__item-delete" v-if="!disabled">
                <i class="el-icon-download"></i>
              </span>
              <span @click="handleRemove(file)" class="el-upload-list__item-delete" v-if="!disabled">
                <i class="el-icon-delete"></i>
              </span>
            </span>
          </div>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible">
          <img :src="dialogImageUrl" alt="" width="100%">
          <video :src="dialogImageUrl" controls  width="100%">
            浏览器不支持此插件
          </video>
        </el-dialog>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>

import { getUpFile, getDeleteFile } from '@/api/uploadFile'

export default {
  data() {
    return {
      dialogImageUrl: '',
      dialogVisible: false,
      disabled: false,
      // 图片列表
      fileList: [],
      queryId: '',
      form: {
        title: '',
        author: '',
        img: '',
        described: '',
        display_time: undefined,
        type: [],
        content: ''
      }
    }
  },
  // 路由进入的时候
  beforeRouteEnter(to, from, next) {
    console.log('---- 4 ----')
    console.log(to)
    console.log(from)
    next()
  },
  // 路由离开之前
  beforeRouteLeave(to, from, next) {
    console.log('---- 5 ----')
    console.log(to)
    console.log(from)
    next()
  },
  created() {
    this.init()
  },
  methods: {
    init() {
    },
    // 上传图片
    beforeUpload(file) {
      console.log(file)
      let param = new FormData()
      param.append('files', file)
      console.log(param)
      getUpFile(param).then(res => {
        let url = res.data.mimetype.split('/')[0]
        if(url == 'image' ){
          url = res.data.url
        }else if(url == 'audio' ||  url == 'video'){
          url = 'http://localhost:3000//images/shipin.png'//换成线上地址
        }else {
          url = 'http://localhost:3000//images/wenjian.png'//换成线上地址
        }
        console.log(url)
        let img = {
          url,
          name: res.data.originalname,
          filename: res.data.filename,
        }
        this.fileList.push(img)
      }).catch(e => {
        console.log(e)
      })
      return false
    },
    // 删除图片
    handleRemove(file) {
      this.$confirm('删除图片不可恢复，是否删除图片', '删除图片', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        getDeleteFile(file).then(res => {
          let index = this.fileList.findIndex(item => {
            return item.filename == file.filename
          })
          console.log(index)
          this.fileList.splice(index, 1)
          this.$message({
            type: 'success',
            message: res.message
          })
        })
      }).catch((rej) => {
        this.$message({
          type: 'info',
          message: rej.message
        })
      })
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url
      this.dialogVisible = true
    },
    handleDownload(file) {
      console.log(file)
    }
  }
}
</script>

<style scoped>
  .line {
    text-align: center;
  }
</style>

