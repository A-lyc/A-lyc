<template>
  <div class="app-container">
    <el-form :model="form" label-width="120px" ref="form">
      <el-form-item label="标题">
        <el-input v-model="form.title"/>
      </el-form-item>
      <el-form-item label="作者">
        <el-select placeholder="选择作者" v-model="form.author">
          <el-option label="管理员" value="管理员"/>
          <el-option label="作者" value="作者"/>
        </el-select>
      </el-form-item>
      <el-form-item label="时间">
        <el-col :span="11">
          <el-date-picker placeholder="选择时间" style="width: 100%;" type="date" v-model="form.display_time"/>
        </el-col>
      </el-form-item>
      <el-form-item label="分类">
        <el-checkbox-group v-model="form.type">
          <el-checkbox label="分类1" name="type"/>
          <el-checkbox label="分类2" name="type"/>
          <el-checkbox label="分类3" name="type"/>
          <el-checkbox label="分类4" name="type"/>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="图片">
        <el-upload
          action="#"
          :before-upload="beforeUpload"
          list-type="picture-card"
          :file-list="fileList"
          :limit="1">
          <i class="el-icon-plus" slot="default"></i>
          <div slot="file" slot-scope="{file}">
            <img :src="file.url" alt="" class="el-upload-list__item-thumbnail">
            <span class="el-upload-list__item-actions">
              <span @click="handlePictureCardPreview(file)" class="el-upload-list__item-preview">
                <i class="el-icon-zoom-in"></i>
              </span>
              <span @click="handleDownload(file)" class="el-upload-list__item-delete" v-if="!disabled">
                <i class="el-icon-download"></i>
              </span>
              <span @click="handleRemove(file)" class="el-upload-list__item-delete" v-if="!disabled">
                <i class="el-icon-delete"></i>
              </span>
            </span>
          </div>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible">
          <img :src="dialogImageUrl" alt="" width="100%">
        </el-dialog>
      </el-form-item>
      <el-form-item label="描述">
        <el-input type="textarea" v-model="form.described"/>
      </el-form-item>
      <el-form-item label="内容">
        <el-input type="textarea" v-model="form.content"/>
      </el-form-item>
      <el-form-item>
        <el-button @click="onSubmit" type="primary">提交</el-button>
        <el-button @click="onCancel">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import { setAdd, getListId, getAmend } from '@/api/form'
  import { getUpImage, getDeleteImage } from '@/api/uploadimg'
  import { setDelete } from '@/api/table'

  export default {
    name:'product',
    data() {
      return {
        dialogImageUrl: '',
        dialogVisible: false,
        disabled: false,
        // 图片列表
        fileList: [],
        queryId: '',
        form: {
          title: '',
          author: '',
          img: '',
          described: '',
          display_time: undefined,
          type: [],
          content: ''
        }
      }
    },
    // 路由进入的时候
    beforeRouteEnter(to, from, next) {
      console.log('---- 4 ----')
      console.log(to)
      console.log(from)
      next()
    },
    // 路由离开之前
    beforeRouteLeave(to, from, next) {
      console.log('---- 5 ----')
      console.log(to)
      console.log(from)
      next()
    },
    created() {
      this.init()
    },
    methods: {
      init() {
        this.editInit()
      },
      // 编辑进入
      editInit() {
        let { query } = this.$router.currentRoute
        console.log(query)
        if (!query._id) {
          return
        } else {
          this.queryId = query._id
          getListId(this.queryId).then(res => {
            this.form = res.data[0]
          })
        }
      },
      // 提交表单
      onSubmit() {
        // 添加新新闻
        if (this.queryId === '') {
          this.addClick()
        } else {
          this.amendClick()
        }
      },
      // 添加新新闻
      addClick() {
        this.form.img = this.fileList
        setAdd(this.form).then(res => {
          console.log(res)
          this.$message(res.message)
          setTimeout(() => {
            this.$router.go(0)
          }, 1000)
        }).catch(e => {
          console.log(e)
        })
      },
      // 修改新闻
      amendClick() {
        getAmend(this.queryId, this.form).then(res => {
          console.log(res)
          this.$message(res.message)
          setTimeout(() => {
            this.$router.go(-1)
          }, 1000)
        }).catch(e => {
          console.log(e)
        })
      },
      // 重置表单
      onCancel() {
        this.$confirm('重置表单内容......', '重置', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.form = {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          }
          this.$message({
            type: 'success',
            message: '已重置!'
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消重置'
          })
        })
      },
      // 上传图片
      beforeUpload(file) {
        console.log(file)
        let param = new FormData()
        param.append('files', file)
        getUpImage(param).then(res => {
          console.log(res)
          let img = {
            url: res.data.url,
            name: res.data.originalname,
            filename: res.data.filename
          }
          this.fileList.push(img)
        })
        return false
      },
      // 删除图片
      handleRemove(file) {
        this.$confirm('删除图片不可恢复，是否删除图片', '删除图片', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getDeleteImage(file).then(res => {
            let index = this.fileList.findIndex(item => {
              return item.filename == file.filename
            })
            console.log(index)
            this.fileList.splice(index, 1)
            this.$message({
              type: 'success',
              message: res.message
            })
          })
        }).catch((rej) => {
          this.$message({
            type: 'info',
            message: rej.message
          })
        })

      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url
        this.dialogVisible = true
      },
      handleDownload(file) {
        console.log(file)
      }
    }
  }
</script>

<style scoped>
  .line {
    text-align: center;
  }
</style>

