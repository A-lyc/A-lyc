<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  watch: {
    $route(to, from) {
      console.log('---- 3 ----')
      console.log(to)
      console.log(from)
    }
  }
}
</script>
